(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.btnVdo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhdCTQgmgOgZgYQgYgYgLgdQgMgcAAgcQAAgaAMgcQALgdAZgXQAYgZAogPQAngPA3AAQA+AAAtATQAtATAYAiQAZAjAAAwQAAAvgaAmQgYAmguAWQgvAXg+ABQg2gBgmgPgAg0iGQgVAGgSAOQgRAOgLAZQgLAZAAAmQAAArASAiQASAjAhAUQAhATAuABQANABATgFQATgFASgNQATgNAMgbQAMgbABgrQgBgtgTghQgSgighgSQgggRgngBIgDAAQgTAAgTAGg");
	this.shape.setTransform(39.425,1.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgrCeIgegCIgbgCIgXAAIgMAAIgQAAIgSABIgQAAQgFAAgCgBQgBgBAAAAQgBAAAAAAQAAgBAAAAQgBgBAAAAIACgDQACgCAEAAIAKAAIAIgBQAHgBADgGQADgGACgJQABgOAAgWIAAg0IAAhIIAAgwIAAgZIAAgPQgBgKgEgFQgFgFgLgDIgJgBIgKAAQgEAAgDgBQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABAAABAAIAIgBIAbAAIAZAAIATABIAUgBIAdAAIAfAAQAfgBAiACQAkADAjAKQAhAKAcAXQATAQANAaQAOAaAAAmQAAAYgHAWQgIAWgMARQgNARgNAMQgMAKgVALQgVAMgiAHQggAIgtABIgcgBgAgxiIIgSABIgNACIgEADQgCACAAADIgBAUIAAAdIAAAgIAAA0IABA3IABAcIABARQABAJADAEQAEAGAQAFQAQAFAcAAQAhABAagHQAagGAVgQQAYgRAKgbQAJgaAAghQAAgZgIgUQgGgVgLgOQgKgOgLgIQgXgSgYgIQgYgJgXgCQgUgDgRAAIgFAAg");
	this.shape_1.setTransform(-6.6,1.745);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAAC8QgFAAgEgHQgEgGgIgRIiNkpQgGgNgGgHQgGgIgHgDQgHgEgKgCIgMgCIgKAAQgEAAgBgBQgBgBAAAAQAAAAAAgBQgBAAAAAAQAAgBAAAAQABgDAEgBIAKgBIAsABIAlABIAdgBIAogBIAJABQABAAAAABQABAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAgBAAIgGABIgNABQgFAAgEACQgDACgBADQgBACAAAEQAAAFADAJIAKAXIBfDdIACAAIATgrIAag4IAbg7IAYg0IAOggIAEgKIABgIQAAgDgCgDQgBgCgEgCQgFgBgGAAIgMgBIgGgBQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAgDAEgBIALgBIAmABIAVABIAOgBIAUAAIATgBIAIABQABAAABABQAAAAABABQAAAAABABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBABQAAAAgBAAIgGABIgMABQgIABgIAEQgFADgHAJQgHAJgMAXIgUApIgVAoIgaAyIguBcIgcA4IgPAdQgFAIgFAAIAAAAg");
	this.shape_2.setTransform(-49.075,-0.8235);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#7B1E00").ss(3,1,1).p("AsHk1IYPAAIAAE4IAAEzI4PAAIAAkzg");
	this.shape_3.setTransform(0.025,0.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#CC3300").s().p("AsHDdIAAkyQLAkONPEOIAAEyg");
	this.shape_4.setTransform(0.025,9.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC6600").s().p("AsHCcIAAk4IYPAAIAAE4QtPkNrAENg");
	this.shape_5.setTransform(0.025,-14.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-31.9,158.3,64.9);


(lib.btnPlay = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAgCcIgggBIgRABIgYAAIgWABIgIgBQgBAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBAAAAQABAAAAgBQACgBAEAAIAKAAIAIgCQAHgBADgGQAEgFABgJIABgZIAAgRIAAgiQAAgQgDgKQgDgJgFgIIgJgMIgSgaIgXgfIgWgeIgQgUQgJgLgIgHQgHgIgIgDIgKgEIgKgBQgDAAgCgCQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAAAQAAgBABAAIAHgBIAQAAIAYABIAWAAIAXAAIAggBIAGABQAAAAABABQAAAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQgBAAAAAAIgJADQAAAAgBAAQgBAAAAAAQgBABAAAAQgBAAAAABQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAABIABAGIAFAIIALAQIATAdIAWAgIASAcIAKAQIAKgOIARgZIAUgeIARgaIAKgQIAFgMIACgKQAAgDgCgCQgCgDgHgBIgGgBQAAgBgBAAQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAQABgBAAAAIAHgBIAYABIAYAAIAQAAIAVgBIAPAAIAHABQAAAAABAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAAAQgBABAAAAQgDACgEAAIgKABIgLADQgIADgFAFQgGAEgHAIIgQASIgWAfIgZAiIgVAfIgMARQgFAMgBAKIAAAUIAAAhIAAARIABAZQABAJAEAFQAFAGAKABIANACIAMAAQAEAAACABQABABAAAAQABAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQgBAAgBAAQgCACgFAAIgtgBg");
	this.shape.setTransform(49.225,1.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ACSCgIg4AAIgLgBQgBAAgBAAQAAgBgBAAQAAAAgBgBQAAAAAAgBIABgDIAFgBQADgBACgCQABgDgBgDIgmhUIgCgDIgDAAIhzAAIgDAAIgBADIgbA4IgFAPIgCAKQAAAGAEADQAFADALAAIAHAAQAEAAACABQAAABAAAAQABAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAIgGABIgbgBIgbgBIgVABIgkABIgHgBQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAIAIAAIAHgBQAQgCAJgJQAIgJAIgQICAkCQAEgJAEgEQADgEAEAAQAEAAADADIAGAKIAPAeIAZA0IAfA+IAeA9IAYAwQAKATAIAJQAHAJAHAEQAGADAEAAIAKACIAIAAQAHAAAAAEQABADgFABQgEABgNAAIgmgBgAgPhLIgBADIgwBmIAAACIACABIBeAAIACgBIAAgBIgthnIgBgDIgBgBIgCABg");
	this.shape_1.setTransform(16.6775,1.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAwCdIgpgBIghgBIgfAAIgMAAIgQAAIgSABIgQAAQgFAAgCgBQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAIACgDQACgCAEAAIAKAAIAIgBQAHgBADgGQADgGABgJQACgOAAgWIAAg0IAAhIIAAgwIAAgZIAAgPQgBgKgEgFQgFgFgMgDIgHgBIgJAAQgIAAAAgEQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAABAAIAHgBIAZAAIAZAAIASABIAUgBIAbAAIAXAAIAIABQABAAAAAAQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgDABgEAAIgKAAIgIABQgKACgEAFQgEAFgBALIAAAPIgBAZIAAAwIAABIQAAAnACAVQABAWAIAFQAGAFAOACQAQACAcAAQAUAAAOgCQAPgCAJgIQAFgEADgHQADgIABgGIACgEQAAgBAAAAQABAAAAAAQABgBAAAAQABAAABAAQAAAAABAAQAAABABAAQAAAAABABQAAAAAAABIABAGIgBAMIgCATIgEARQgCAEgCADQgDACgGABIgSABIgwAAg");
	this.shape_2.setTransform(-15.925,1.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbC3IgjAAIgTAAIgaABIgZAAQgGAAgDgBQAAgBgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAAAgBIAIgBIALAAIAIgCQAJgBADgHQADgHACgLQACgQAAgbIAAg9IAAhVIAAg4IAAgeIgBgRQAAgNgFgGQgFgHgOgCIgJgBIgMAAIgIgBQAAAAgBgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAABgBQAAAAABAAIAJgBIAfAAIAdABIAVAAIAogBIAoAAQAiAAAWAFQAVAGALAGQALAHAFAEQAJAHAKAQQAIAPABATQAAAjgSAbQgSAagfAOQgeAPgoAAIgGAAIgHAAIgDgBQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQAAgDADgCIALgBQAQAAASgJQARgJAMgSQALgSACgZQgBgJgCgMQgBgMgHgOQgHgOgPgMQgQgMgQgEQgPgEgIABIgNAAIgJACQAAAAgBAAQAAAAgBABQAAAAgBABQAAAAAAABIgBAGIAADCIAAA9QAAAbACAQQABALAFAHQADAHANABIANACIAPAAIAGABQABABAAAAQABAAAAABQAAAAAAAAQABABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAgBABQgCABgGAAIgygBg");
	this.shape_3.setTransform(-50.55,-1.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#7B1E00").ss(3,1,1).p("AsHliIYPAAIAAFmIAAFfI4PAAIAAlfg");
	this.shape_4.setTransform(0.025,0.5063,1,0.8725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CC6600").s().p("AsHCzIAAlmIYPAAIAAFmQtPk0rAE0g");
	this.shape_5.setTransform(0.025,-14.8065,1,0.8725);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC3300").s().p("AsHD9IAAleQLAk2NPE2IAAFeg");
	this.shape_6.setTransform(0.025,9.417,1,0.8725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-32,158.3,65);


(lib.btnLearn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABrB4IgGgFIgegYIgmggIgnghIgnghIgfgcIgQgPIgCAAIAFB+QAAASADAHQAEAHAFACIAKABIAJABIAFABIACACQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBABIgGAAIgeAAIgRgBIgPABIgZAAIgGAAQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAIACgCIAEgBIAJgBIAIgBQAHgBACgIQACgJAAgTIAEi4QAAgEABgDQACgDADAAQADAAAEADIAJAHIAMALIAaAXIAkAfIAnAiIAWATIAZAWIAVASIALAKIACAAIgEiJQAAgOgDgGQgDgGgHgCIgJgBIgKgBIgFAAIgBgDQAAAAAAgBQABAAAAAAQAAgBABAAQAAAAABAAIAGgBIAcABIAUAAIAMAAIAYgBIAGABQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAABgBAAIgEAAIgGABIgGABQgHABgDAGQgDAFAAANIgEDDQAAAFgCADQgBAAAAABQAAAAgBABQgBAAAAAAQgBAAAAAAQgFAAgEgCg");
	this.shape.setTransform(51.175,0.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ABpB2QgPgBgJgBQgJgCgHgDQgMgFgLgLQgMgMgPgSIgPgRIgLgQIgIgJIgDgCIgEAAIghAAIgCAAIgBACIAAAEIAAAnQABARABAKQABAIADADQACAFAIABIAKABIAIAAIAEABIABACQAAABAAAAQAAAAAAABQAAAAgBAAQAAAAgBABIgGABIgXgBIgVAAIgNAAIgMAAIgQAAIgRABIgGgBQAAgBAAAAQgBAAAAAAQAAgBAAAAQAAAAAAgBIABgCIAFgBIAHAAIAGgBQAFgBACgFQADgDAAgIQACgKAAgRIAAgnIAAg1IAAgkIAAgTIAAgMQgBgHgDgEQgEgDgIgCIgHgBIgIgBIgEAAQgBAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABAAAAgBQAAAAABAAIAGAAIAUAAIASAAIAMAAIASAAIAXAAIARAAQASAAARACQATADAPAHQAFADAGAHQAGAGAEAJQAFAIAAALQAAAQgMARQgMARgbARIAsAwQAUAUARAPQAKAIAIAFQAHAEAGACIAIABIAFABIAEAAIADABIABACQAAABAAAAQAAAAAAABQAAAAgBAAQAAABgBAAIgFABgAg7hjIgCABIgBADIAABcIABADIACACIAOACIAOABIARgBQAFgBAEgDQAIgEAIgLQAHgLAAgTQAAgWgJgMQgJgMgNgFQgMgFgMAAIgNAAIgJACg");
	this.shape_1.setTransform(22.075,0.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABtB5IgqgBIgIAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBIABgCIAEgBIADgCQABgCgBgDIgcg/IgCgCIgCAAIhWAAIgCAAIgBACIgUAqIgEALIgBAIQgBAFAEACQADACAIAAIAGAAQABAAABAAQAAAAABAAQAAAAABABQAAAAAAAAIABACQAAABAAAAQAAAAAAABQAAAAAAAAQgBABAAAAIgFABIgUgBIgVAAIgPAAIgbABIgGgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAAAgBIABgCIADgBIAFAAIAGgBQAMgBAHgHQAGgHAFgMIBhjBQADgGADgEQACgDADAAQADABACACQACACADAFIALAXIATAnIAXAuIAXAtIARAkQAIAOAGAIQAFAGAFADQAEACAEABIAHABIAHAAQAFAAAAADQAAABAAAAQAAAAgBABQAAAAgBAAQAAABgBAAIgNABIgdAAgAgLg4IgBACIgkBNIAAABIACABIBGAAIABgBIAAgBIghhNIgBgCIgBgBIgBABg");
	this.shape_2.setTransform(-8.3469,0.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAjB3IgegBIgXgBIgTAAIgJAAIgMABIgNAAIgMAAIgGgBQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAIABgCIAGgBIAHAAIAFgBQAGgBACgFQADgEAAgHQACgKAAgRIAAgnIAAg2IAAgkIAAgTIAAgLQgBgHgEgEQgDgDgIgCIgHgBIgIgBIgEAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQgBAAAAgBQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAABAAIAGgBIAUAAIATABIAOAAIAPAAIAXAAIAbAAIAXAAIALAAIAKgBIAGgBIAEgBIACAAIACAAIAAACIgBAGIgBAPIgBAGIAAAIIgBAGIgCADQAAABAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAIgCgBIAAgDIgBgFIgCgGQgBgEgFgDQgFgDgNgCIgLAAIgRAAIgSgBIgLAAIgCABIgBACIAABNIABACIACABIAMAAIATAAIAUAAIANAAIAKgCIAHgDIAEgDIACgBIACABIAAACIAAAGIgCAQIgBAHIgBAJIAAAFIAAAEQgBAAAAABQAAAAAAABQgBAAAAAAQgBABAAAAIgDgBIgBgCIgBgGIAAgFQgCgFgEgDQgEgEgKgBIgLAAIgRgBIgSAAIgMAAIgBABIgBACIAAAZIAAAPIAAASIAAANQABAQAJAFQAMAGAcgBIARgBQAJAAAIgDQAHgCAEgGQADgFACgKIABgEIADgBQAAAAABABQAAAAABAAQAAAAAAABQABAAAAABIAAAFIgBAKIgBAOIgCAKQgCAGgEABQgEABgLAAIglAAg");
	this.shape_3.setTransform(-33.5,0.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAlCLIgfgBIgZgBIgZAAIgKAAIgOAAIgPAAIgOABIgGgBQAAAAgBgBQAAAAgBAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAIAGgBIAIAAIAHgBQAGgBACgGQADgFABgIIACggIAAguIAAg/IAAgrIAAgWIgBgNQAAgJgEgFQgEgFgKgCIgGgBIgIAAIgFgBQgBAAAAAAQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAIAHgBIAVABIAUAAIAQABIAPgBIAWAAIATgBIAGABQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAIgGABIgIAAIgHABQgJABgDAFQgDAFgBAKIAAANIgBAWIAAArIAAA/IABA2QACAUAGAEQAEADAEACQAGACAKAAIAaABQARABAMgCQAMgCAIgHQAEgEADgGQADgGABgGIABgEQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAAAAAIABAFIgBAKIgCARIgDAPQgBAEgDACQgCACgFABIgQABIgoAAg");
	this.shape_4.setTransform(-57.025,-1.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#7B1E00").ss(3,1,1).p("AsHk1IYPAAIAAE4IAAEzI4PAAIAAkzg");
	this.shape_5.setTransform(0.025,0.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CC3300").s().p("AsHDdIAAkyQLAkONPEOIAAEyg");
	this.shape_6.setTransform(0.025,8.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CC6600").s().p("AsHCcIAAk4IYPAAIAAE4QtPkNrAENg");
	this.shape_7.setTransform(0.025,-15.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.1,-32.4,158.3,64.9);


// stage content:
(lib.index = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.learnBtn.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('./learn.html', '_blank');
		});
		
		
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.playBtn.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('./play.html', '_blank');
		});
		
		
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.vdoBtn.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('./vdoPage.html', '_blank');
		});
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.playBtn.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('./play.html', '_blank');
		});
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// playBtn
	this.vdoBtn = new lib.btnVdo();
	this.vdoBtn.name = "vdoBtn";
	this.vdoBtn.setTransform(782.45,280.45,1,1,0,0,0,0,0.5);
	new cjs.ButtonHelper(this.vdoBtn, 0, 1, 1);

	this.playBtn = new lib.btnPlay();
	this.playBtn.name = "playBtn";
	this.playBtn.setTransform(570.2,280.45,1,1,0,0,0,0,0.5);
	new cjs.ButtonHelper(this.playBtn, 0, 1, 1);

	this.learnBtn = new lib.btnLearn();
	this.learnBtn.name = "learnBtn";
	this.learnBtn.setTransform(353.5,280.45);
	new cjs.ButtonHelper(this.learnBtn, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.learnBtn},{t:this.playBtn},{t:this.vdoBtn}]}).wait(1));

	// ABC
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#333333").s().p("AC6HsQgdgEgogdQg0gmhghTIhShHQgxgpgdgeQhFhIANg+QAEgPAMgWQAPgbADgJQAHgRADgYIAEgqQAEgkANhHIAhiuQAJgwAKgTQARglAggKQANgEAOACQAOACAKAIQAaAVgDA1QgCAmgLAnIgRAxQgKAdgDAUQgEAVAAArIAACdQAAAuAKAYQAGAOANAPIAYAbQAhAkBEBfQA/BWAqAqQAZAYAJAOQAPAZgGAVQgGASgSAJQgOAHgPAAIgJAAg");
	this.shape.setTransform(305.7608,191.6124,0.2748,0.2748);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AC6HsQgdgEgogdQg0gmhghTIhShHQgxgpgdgeQhFhIANg+QAEgPAMgWQAPgbADgJQAHgRADgYIAEgqQAEgkANhHIAhiuQAJgwAKgTQARglAggKQANgEAOACQAOACAKAIQAaAVgDA1QgCAmgLAnIgRAxQgKAdgDAUQgEAVAAArIAACdQAAAuAKAYQAGAOANAPIAYAbQAhAkBEBfQA/BWAqAqQAZAYAJAOQAPAZgGAVQgGASgSAJQgOAHgPAAIgJAAg");
	this.shape_1.setTransform(280.5608,188.5124,0.2748,0.2748);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#660000").s().p("AlMA2QFElNFVFMQiLA8jCAAQjCAAiKg7g");
	this.shape_2.setTransform(288.7541,157.894,0.2136,0.2094);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AlSDtQiLg9AAhYQAAhXC6iKQC7iMC7A1QC7A1BoBXQBoBVAABXQABBYiNA9IgEACQlVlMlEFNIgHgDg");
	this.shape_3.setTransform(288.7274,154.0116,0.2136,0.2094);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_4.setTransform(300.2451,135.4205,0.2748,0.2748);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_5.setTransform(302.3759,135.9277,0.2748,0.2748);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_6.setTransform(272.3451,135.7705,0.2748,0.2748);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_7.setTransform(274.6259,135.9277,0.2748,0.2748);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#35B6DD").s().p("AkKP9QjHhFiOiJQiPiJhNjMQhPjMAAkMQAAj5BLjLQBKjKCPiRQCIiMDLhMQDKhMDuAAQCFAABrAPQBqAPBaAXQBeAbBOAiQBMAhA6AcIAAH8Ig+AAQgngig8guQg9gvhLgrQhOgthagfQhagfhogBQhxAAhoAkQhlAlhYBTQhTBQgzCDQg0CEABC9QAADEA4CFQA3CDBUBNQBXBNBoAiQBpAgBoAAQBiAABigeQBfgdBSgzQBFgnA7gvQA7guAmgiIA5AAIAAH2IiXBCQhIAehPAYQhmAdhbAQQhaAPieAAQjpAAjFhFg");
	this.shape_8.setTransform(290.4496,158.43,0.2748,0.2748);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#333333").s().p("AkKP9QjHhFiOiJQiPiJhNjMQhPjNAAkLQAAj4BLjMQBLjLCOiQQCIiMDLhMQDKhMDuAAQCFAABrAPQBqAOBaAYQBfAbBNAiQBMAhA6AcIAAH8Ig+AAQgoghg7gvQg9gvhLgrQhOguhageQhbgghmAAQhzAAhnAkQhlAkhYBUQhTBQgzCDQgzCEAAC9QAADEA4CFQA3CDBUBMQBWBOBpAiQBpAgBoAAQBiAABigeQBfgdBSgzQBFgnA7gvQA8guAlgiIA5AAIAAH1IiXBDQhIAehPAYQhnAdhaAQQhaAPieAAQjpAAjFhFg");
	this.shape_9.setTransform(292.5938,160.197,0.2748,0.2748);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#333333").s().p("AlpJ/QgQgHgJgPQgJgPAAgSQAAgYAZgmQAng5A+g9QAlgkBQhGIEYjyQA4gvAagfQAogxAIgyQAFgkgKgyQgOg6gFgdQgJgzABhhQABhCAHghQAFgbAMgZQALgYAQgNQATgRAUACQAnAFARBIQASBRADAkQAEAtgFBPIgKCzQgEBLgDAlQgGA9gLAxQgPBCgdAiQgUAXgjAUIhAAhQhGAkhrBXQh5BigzAgIg8AlQghAXgRAZIgQAYQgJAOgJAHQgOALgRABIgHABQgOAAgMgHg");
	this.shape_10.setTransform(535.7226,105.8703,0.2387,0.2387,90);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AlpJ/QgQgHgJgPQgJgPAAgSQAAgYAZgmQAng5A+g9QAlgkBQhGIEYjyQA4gvAagfQAogxAIgyQAFgkgKgyQgOg6gFgdQgJgzABhhQABhCAHghQAFgbAMgZQALgYAQgNQATgRAUACQAnAFARBIQASBRADAkQAEAtgFBPIgKCzQgEBLgDAlQgGA9gLAxQgPBCgdAiQgUAXgjAUIhAAhQhGAkhrBXQh5BigzAgIg8AlQghAXgRAZIgQAYQgJAOgJAHQgOALgRABIgHABQgOAAgMgHg");
	this.shape_11.setTransform(554.0726,100.1703,0.2387,0.2387,90);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#660000").s().p("AlMgMQFEhCFVBBQiLA7jCAAQjCAAiKg6g");
	this.shape_12.setTransform(517.0675,84.6941,0.2387,0.2387,-90);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AlRBhQiNg9AAhWQAAhXCTBIQCSBGDGgDQDGgCCGhEQCGhFAABXQgBBWiMA9IgEACQlUhBlEBCIgHgDg");
	this.shape_13.setTransform(514.3761,84.7239,0.2387,0.2387,-90);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_14.setTransform(502.2685,91.2237,0.2387,0.2387);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_15.setTransform(499.0496,91.628,0.2387,0.2387);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_16.setTransform(502.2685,76.7737,0.2387,0.2387);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_17.setTransform(499.0496,76.878,0.2387,0.2387);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B5C035").s().p("AuAQZMAAAggxIMuAAQD8AAB3ARQB1ARB0A6QB3A8A7BnQA6BlAACEQAACYhQB1QhRBziSBBIAAALQDNApB6B/QB3CBAADSQABCYg9B4Qg+B3hrBPQh8BdiUAoQiVAnjlAAgAlmKZIAnAAQDkAABggCQBjgBBTgkQBVgjAgg6QAgg7AAhMQgBhkglg1Qgog3hdgbQg/gShtgCQhwgBh5AAIh2AAgAlmjbIBUAAQCBAABZgFQBagEA0gYQBJggAXgzQAWg0AAhEQAAg0gZg0Qgbg0hCgaQg8gWhVgCQhagCifAAIgyAAg");
	this.shape_18.setTransform(520.5499,85.236,0.2387,0.2387);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#333333").s().p("AuBQZMAAAggxIMvAAQD8AAB3ARQB1ARBzA6QB4A8A8BnQA5BlAACEQAACYhQB1QhRBziSBBIAAALQDOApB5B/QB4CBAADSQgBCYg8B4Qg+B3hrBPQh8BdiUAoQiWAnjkAAgAlnKZIAoAAQDkAABhgCQBigBBUgkQBUgjAhg6QAeg7AAhMQAAhkgmg1Qgng3hdgbQhAgShtgCQhvgBh5AAIh3AAgAlnjbIBVAAQCAAABbgFQBZgEA0gYQBJggAWgzQAYg0AAhEQgBg0gZg0Qgbg0hCgaQg7gWhXgCQhZgCieAAIg0AAg");
	this.shape_19.setTransform(522.8319,84.2158,0.2387,0.2387);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("Ak+EmQgMgKgEgQIgBgGIgIgCQgVgIgVgdQghgsgNgtIgKgvQgGgcgIgRIgLgTQgGgLgCgIQgCgIgBgOIgBgXQgBgXgOglQgPgpgDgNQgMgtAEgsQACgZAIgNQAKgQAUgFQAUgGAQAKQAPAJARAfQAbAyAHAXIAKAdQAEAIAMARQALAPAEALQAEAIACAQQADARADAIQADAIAHAKIANASQALARAOAgQAWAyAHAeIAGAcQADARADALIACAEIAegPQAtgUAngIIArgIQAagFARgGQAMgEAYgMQAXgMANgFQASgGAhgFQAogFAMgDQAQgEAXgJIAmgPQAbgJBHgSQA+gRAigPQAdgMAMgDQAXgFARAIQATAKAGAaQAEAVgGAZQgJAkgXANQgIAFgPADIgaAFQgPAEgmAVQhSAuhxAhQhIAViFAbIh1AYQgyAKghAJQgkALgRABIgIAAQgYAAgQgMg");
	this.shape_20.setTransform(855.9464,164.2727,0.2984,0.2984,0,0,180);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#660000").s().p("AlMgMQFEhCFVBBQiLA7jCAAQjCAAiKg6g");
	this.shape_21.setTransform(828.9065,178.8237,0.2984,0.2984);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AlRBhQiNg9AAhWQAAhXCTBIQCSBGDGgDQDGgCCGhEQCGhFAABXQgBBWiMA9IgEACQlUhBlEBCIgHgDg");
	this.shape_22.setTransform(828.8692,175.4587,0.2984,0.2984);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_23.setTransform(839.9391,154.052,0.2984,0.2984);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_24.setTransform(839.8661,151.5144,0.2984,0.2984);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_25.setTransform(817.5391,154.052,0.2984,0.2984);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_26.setTransform(817.7161,151.5144,0.2984,0.2984);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("Ak+EmQgMgKgEgQIgBgGIgIgCQgVgIgVgdQghgsgNgtIgKgvQgGgcgIgRIgLgTQgGgLgCgIQgCgIgBgOIgBgXQgBgXgOglQgPgpgDgNQgMgtAEgsQACgZAIgNQAKgQAUgFQAUgGAQAKQAPAJARAfQAbAyAHAXIAKAdQAEAIAMARQALAPAEALQAEAIACAQQADARADAIQADAIAHAKIANASQALARAOAgQAWAyAHAeIAGAcQADARADALIACAEIAegPQAtgUAngIIArgIQAagFARgGQAMgEAYgMQAXgMANgFQASgGAhgFQAogFAMgDQAQgEAXgJIAmgPQAbgJBHgSQA+gRAigPQAdgMAMgDQAXgFARAIQATAKAGAaQAEAVgGAZQgJAkgXANQgIAFgPADIgaAFQgPAEgmAVQhSAuhxAhQhIAViFAbIh1AYQgyAKghAJQgkALgRABIgIAAQgYAAgQgMg");
	this.shape_27.setTransform(802.5536,164.7727,0.2984,0.2984);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#EF8F93").s().p("AIPQZIiRmoIsIAAIiTGoIogAAMAMHggxIJuAAMAMGAgxgAkIDwIICAAIkArug");
	this.shape_28.setTransform(829.123,177.3293,0.2984,0.2984);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#333333").s().p("AIPQZIiSmoIsGAAIiUGoIogAAMAMGggxIJuAAMAMHAgxgAkIDwIICAAIkArug");
	this.shape_29.setTransform(831.5862,179.3661,0.2984,0.2984);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#333333").s().p("AC6HsQgdgEgogdQg0gmhghTIhShHQgxgpgdgeQhFhIANg+QAEgPAMgWQAPgbADgJQAHgRADgYIAEgqQAEgkANhHIAhiuQAJgwAKgTQARglAggKQANgEAOACQAOACAKAIQAaAVgDA1QgCAmgLAnIgRAxQgKAdgDAUQgEAVAAArIAACdQAAAuAKAYQAGAOANAPIAYAbQAhAkBEBfQA/BWAqAqQAZAYAJAOQAPAZgGAVQgGASgSAJQgOAHgPAAIgJAAg");
	this.shape_30.setTransform(980.9106,555.0688);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#333333").s().p("AC6HsQgdgEgogdQg0gmhghTIhShHQgxgpgdgeQhFhIANg+QAEgPAMgWQAPgbADgJQAHgRADgYIAEgqQAEgkANhHIAhiuQAJgwAKgTQARglAggKQANgEAOACQAOACAKAIQAaAVgDA1QgCAmgLAnIgRAxQgKAdgDAUQgEAVAAArIAACdQAAAuAKAYQAGAOANAPIAYAbQAhAkBEBfQA/BWAqAqQAZAYAJAOQAPAZgGAVQgGASgSAJQgOAHgPAAIgJAAg");
	this.shape_31.setTransform(889.1106,543.6188);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#660000").s().p("AlMA2QFElNFVFMQiLA8jCAAQjCAAiKg7g");
	this.shape_32.setTransform(918.8268,432.1736,0.7774,0.7621);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AlSDtQiLg9AAhYQAAhXC6iKQC7iMC7A1QC7A1BoBXQBoBVAABXQABBYiNA9IgEACQlVlMlEFNIgHgDg");
	this.shape_33.setTransform(918.7296,418.043,0.7774,0.7621);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_34.setTransform(960.35,350.55);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_35.setTransform(968.15,352.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_36.setTransform(859,351.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_37.setTransform(867.1,352.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#35B6DD").s().p("ACuP9QjGhFiOiJQglgkghgoQhdhyg5iXQhPjNAAkLQAAj5BLjLQA5icBhh5QAeglAhgiQCIiLDKhMQCNg1CggQIAAG0QhjAlhVBQQhTBRgzCDQg0CEAAC8QAADFA5CFQA3CDBUBMQBPBHBfAiIAAG3QibgPiJgwg");
	this.shape_38.setTransform(880.975,434.275);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#0099FF").s().p("Am4Q8IAAm3IASAHQBpAgBnAAQBjAABhgeQBfgdBSgzQA9gjA1goIAOgLQA7guAmgiIA5AAIAAH2IiXBCIgRAHQhBAahFAVQhnAdhZAQQhaAPieAAQhHAAhEgGgAF7mWQgogig7guIgHgFQg6gshIgpQhNgthZgfQhbgfhngBQhyAAhnAkIgGACIAAm0QBFgHBHAAQCFAABrAPQBpAPBaAXQBKAVBAAaIAiAOQBMAhA6AcIAAH8g");
	this.shape_39.setTransform(971.675,434.25);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#333333").s().p("AkKP9QjHhFiOiJQiPiJhNjMQhPjNAAkLQAAj4BLjMQBLjLCOiQQCIiMDLhMQDKhMDuAAQCFAABrAPQBqAOBaAYQBfAbBNAiQBMAhA6AcIAAH8Ig+AAQgoghg7gvQg9gvhLgrQhOguhageQhbgghmAAQhzAAhnAkQhlAkhYBUQhTBQgzCDQgzCEAAC9QAADEA4CFQA3CDBUBMQBWBOBpAiQBpAgBoAAQBiAABigeQBfgdBSgzQBFgnA7gvQA8guAlgiIA5AAIAAH1IiXBDQhIAehPAYQhnAdhaAQQhaAPieAAQjpAAjFhFg");
	this.shape_40.setTransform(932.9,440.55);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#333333").s().p("AlpJ/QgQgHgJgPQgJgPAAgSQAAgYAZgmQAng5A+g9QAlgkBQhGIEYjyQA4gvAagfQAogxAIgyQAFgkgKgyQgOg6gFgdQgJgzABhhQABhCAHghQAFgbAMgZQALgYAQgNQATgRAUACQAnAFARBIQASBRADAkQAEAtgFBPIgKCzQgEBLgDAlQgGA9gLAxQgPBCgdAiQgUAXgjAUIhAAhQhGAkhrBXQh5BigzAgIg8AlQghAXgRAZIgQAYQgJAOgJAHQgOALgRABIgHABQgOAAgMgHg");
	this.shape_41.setTransform(621.146,574.5889,1,1,90);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#333333").s().p("AlpJ/QgQgHgJgPQgJgPAAgSQAAgYAZgmQAng5A+g9QAlgkBQhGIEYjyQA4gvAagfQAogxAIgyQAFgkgKgyQgOg6gFgdQgJgzABhhQABhCAHghQAFgbAMgZQALgYAQgNQATgRAUACQAnAFARBIQASBRADAkQAEAtgFBPIgKCzQgEBLgDAlQgGA9gLAxQgPBCgdAiQgUAXgjAUIhAAhQhGAkhrBXQh5BigzAgIg8AlQghAXgRAZIgQAYQgJAOgJAHQgOALgRABIgHABQgOAAgMgHg");
	this.shape_42.setTransform(697.946,550.5389,1,1,90);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#660000").s().p("AlMgMQFEhCFVBBQiLA7jCAAQjCAAiKg6g");
	this.shape_43.setTransform(542.5295,486.625,1,1,-90);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AlRBhQiNg9AAhWQAAhXCTBIQCSBGDGgDQDGgCCGhEQCGhFAABXQgBBWiMA9IgEACQlUhBlEBCIgHgDg");
	this.shape_44.setTransform(531.249,486.75,1,1,-90);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_45.setTransform(481.1,514.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_46.setTransform(467.45,516);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_47.setTransform(481.1,452.55);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_48.setTransform(467.45,454.25);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#B5C035").s().p("AnhQZIAAmBIBIgBQBigBBUgkQBUgjAhg6QAfg7AAhMQAAhkgmg1Qgog3hdgbQg/gShugCIg6AAIAAluIAKgBQBagEA0gYQBJggAXgzQAXg0AAhEQAAg0gag0Qgbg0hCgaQg7gWhXgCIgGAAIAAmDQDxAAByARQB1ARBzA6QB3A8A8BnQA5BlAACEQAACYhQB1QhQBziTBBIAAALQDOApB5B/QB4CBAADSQAACYg9B4Qg+B3hrBPQh8BdiTAoQiVAnjlAAg");
	this.shape_49.setTransform(598.775,488.225);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#66CC33").s().p("AmfQZMAAAggxIMuAAIARAAIAAGDQhZgCiaAAIgzAAIAAG8IBVAAQB6AABXgEIAAFuIivgBIh3AAIAAILIAoAAID+gBIAAGBg");
	this.shape_50.setTransform(509.025,488.225);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#333333").s().p("AuBQZMAAAggxIMvAAQD8AAB3ARQB1ARBzA6QB4A8A8BnQA5BlAACEQAACYhQB1QhRBziSBBIAAALQDOApB5B/QB4CBAADSQgBCYg8B4Qg+B3hrBPQh8BdiUAoQiWAnjkAAgAlnKZIAoAAQDkAABhgCQBigBBUgkQBUgjAhg6QAeg7AAhMQAAhkgmg1Qgng3hdgbQhAgShtgCQhvgBh5AAIh3AAgAlnjbIBVAAQCAAABbgFQBZgEA0gYQBJggAWgzQAYg0AAhEQgBg0gZg0Qgbg0hCgaQg7gWhXgCQhZgCieAAIg0AAg");
	this.shape_51.setTransform(566.9,484.825);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("Ak+EmQgMgKgEgQIgBgGIgIgCQgVgIgVgdQghgsgNgtIgKgvQgGgcgIgRIgLgTQgGgLgCgIQgCgIgBgOIgBgXQgBgXgOglQgPgpgDgNQgMgtAEgsQACgZAIgNQAKgQAUgFQAUgGAQAKQAPAJARAfQAbAyAHAXIAKAdQAEAIAMARQALAPAEALQAEAIACAQQADARADAIQADAIAHAKIANASQALARAOAgQAWAyAHAeIAGAcQADARADALIACAEIAegPQAtgUAngIIArgIQAagFARgGQAMgEAYgMQAXgMANgFQASgGAhgFQAogFAMgDQAQgEAXgJIAmgPQAbgJBHgSQA+gRAigPQAdgMAMgDQAXgFARAIQATAKAGAaQAEAVgGAZQgJAkgXANQgIAFgPADIgaAFQgPAEgmAVQhSAuhxAhQhIAViFAbIh1AYQgyAKghAJQgkALgRABIgIAAQgYAAgQgMg");
	this.shape_52.setTransform(308.5488,394.942,1,1,0,0,180);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#660000").s().p("AlMgMQFEhCFVBBQiLA7jCAAQjCAAiKg6g");
	this.shape_53.setTransform(217.475,443.7295);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AlRBhQiNg9AAhWQAAhXCTBIQCSBGDGgDQDGgCCGhEQCGhFAABXQgBBWiMA9IgEACQlUhBlEBCIgHgDg");
	this.shape_54.setTransform(217.35,432.449);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_55.setTransform(254.25,360.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_56.setTransform(254.4,352.25);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AhgBgQgngoAAg4QAAg4AngoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA4goAoQgoAog5ABQg4gBgogog");
	this.shape_57.setTransform(179.95,360.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("Ai+C/QhPhPAAhwQAAhvBPhPQBPhPBvAAQBwAABPBPQBPBPAABvQAABwhPBPQhPBPhwAAQhvAAhPhPg");
	this.shape_58.setTransform(180.1,352.25);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("Ak+EmQgMgKgEgQIgBgGIgIgCQgVgIgVgdQghgsgNgtIgKgvQgGgcgIgRIgLgTQgGgLgCgIQgCgIgBgOIgBgXQgBgXgOglQgPgpgDgNQgMgtAEgsQACgZAIgNQAKgQAUgFQAUgGAQAKQAPAJARAfQAbAyAHAXIAKAdQAEAIAMARQALAPAEALQAEAIACAQQADARADAIQADAIAHAKIANASQALARAOAgQAWAyAHAeIAGAcQADARADALIACAEIAegPQAtgUAngIIArgIQAagFARgGQAMgEAYgMQAXgMANgFQASgGAhgFQAogFAMgDQAQgEAXgJIAmgPQAbgJBHgSQA+gRAigPQAdgMAMgDQAXgFARAIQATAKAGAaQAEAVgGAZQgJAkgXANQgIAFgPADIgaAFQgPAEgmAVQhSAuhxAhQhIAViFAbIh1AYQgyAKghAJQgkALgRABIgIAAQgYAAgQgMg");
	this.shape_59.setTransform(129.8512,396.642);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FF3399").s().p("AIPFNIiRmoIsIAAIiTGoIogAAID1qYIaRAAID1KYg");
	this.shape_60.setTransform(218.05,510.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#EF8F93").s().p("AtILNIIS2ZIJuAAIIRWZgAkII9IICAAIkArug");
	this.shape_61.setTransform(218.05,405.475);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#333333").s().p("AIPQZIiSmoIsGAAIiUGoIogAAMAMGggxIJuAAMAMHAgxgAkIDwIICAAIkArug");
	this.shape_62.setTransform(226.45,445.675);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#35B6DD").s().p("AkTEUIAAonIInAAIAAIng");
	this.shape_63.setTransform(-277.225,284.325);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#B5C035").s().p("AkTEUIAAonIInAAIAAIng");
	this.shape_64.setTransform(-277.225,189.775);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#EF8F93").s().p("AkTEUIAAonIInAAIAAIng");
	this.shape_65.setTransform(-277.225,100.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Text
	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#7B1E00").ss(3,1,1).p("EAkBAB5QAAA2AAAsQgBArgCAZQgCASgFAKQgFALgMADQgFABgIABQgHAAgJAAQgHAAgDADQgCADAAACQAAAFAEACQADACAIAAQAMAAAPgBQAPAAAOgBQAPAAAMAAQANgBAGAAQASAAAXABQAXAAAeABQAeABAlABQAlABAtAAQAWAAAJgDQAJgDADgOQADgJACgRQADgRABgRQADgRAAgKQAAgGgCgGQgCgGgEAAQgEAAgCADQgCADgBAGQgEAYgIANQgIAOgPAHQgRAGgVACQgWACgQAAQg9ABgZgOQgYgNAAgnQAAgNAAgWQAAgWAAgWQAAgXAAgOIAAg/QAAgEABgCQABgCACAAQAJAAASAAQASAAAVABQAVABASAAQAQABAHAAQAWADAKAIQAKAIADAMQABAIABAHQAAAHAAAGQAAADACACQACACAEAAQAFgBACgGQABgGAAgFQAAgDAAgJQABgKABgLQABgLABgIQAEgdABgNQABgLAAgDQAAgEgBgCQgDgCgCAAQgDAAgCACQgEAEgEAEQgGAEgJADQgKACgNACQgIAAgUABQgUAAgYABQgXAAgUAAQgTAAgJAAQgCAAgCgDQgBgCAAgEIAAjBQAAgDABgCQACgCACAAQAIAAASABQASAAAVABQAWAAARAAQASABAGABQAdADALAIQAJAHAEALQADAHABAIQABAIAAAFQAAAFACADQABACAEAAQAFAAABgFQACgFACgDQAAgFABgKQABgLAAgKQABgLABgEQABgbADgKQACgLAAgDQAAgDgBgCQgBgCgDAAQgDAAgEABQgCABgFABQgFABgIACQgJABgMABQgFABgVAAQgVAAgdAAQgeAAgeAAQgegBgXAAQgWAAgJAAQgLAAgUAAQgUgBgWAAQgXgBgVAAQgJAAgFACQgEABAAAFQAAAEAEACQAEACAGAAQAJAAAIAAQAJABAFACQATAFAIAJQAHAJABATQABAMAAAQQAAAQAAAgQAAAfAAA7gAQ6CWQACAAADABQACACABADIA/CeQACAHgCAFQgDAEgFABQgGABgBACQgDACAAADQAAAEAHACQAGABALAAQA0ABApAAQApABAVAAQATAAAIgBQAEABAFAAQAUAAAYgBQAYgCAMAAQAMAAAYACQAYABAaAAQAJAAAFgCQAFgCAAgFQAAgDgEgCQgDgDgFAAQgGAAgGgBQgHAAgKgCQgLgCgHgFQgHgFAAgLQAAgKABgJQAAgIACgKIAmktIADAAQAOAcARAiQASAjAOAdQAOAdAEAIQAEAJAMAXQAMAXAPAdQAPAcAOAaQANAZAIAPQAKARAHALQAIALAHAAQAGAAAHgIQAGgJANgbICulZIADAAIAtFQQACARgBAIQgBAHgEACQgEABgCACQgDACAAADQAAADAFADQAFACAOABQANABAYABQAYAAAcABQAbABAWAAQAVABAJAAQAJAAAGgDQAGgCAAgFQAAgDgEgCQgDgCgGAAQgHAAgLgBQgLgCgRgEQgSgFgIgSQgJgSgFgkIhJnhQgDgMgFgGQgFgHgFAAQgGAAgFAFQgGAFgFAKIjZG1IjZmwQgIgPgGgFQgFgFgFAAQgFAAgFAGQgFAFgCAKIhQH6QgCAUgHASQgIASgQAEQgJABgGAAQgFAAgFAAQgCAAgCABQgDgBgDAAQgGAAgIAAQgGgBgKgBQgHgBgKgHQgLgGgMgRQgNgSgQgjQgQgkgXg3QgYg3gag9Qgag9gZg5QgYg5gRgpQgTgpgGgOQgFgNgFgGQgFgFgJAAQgGAAgFAHQgGAHgHARIjTHoQgMAdgOASQgPARgaAEQgGAAgGABQgHAAgFAAQgFAAgCADQgDACAAADQAAAFAFACQADACAHAAQAhAAAbgBQAbgCAIAAQATAAAZACQAYABAVAAQAGAAAEgCQADgCAAgFQAAgDgCgCQgCgDgIAAIgMAAQgSAAgHgGQgIgFABgLQAAgHADgNQADgNAGgOIArhqQABgDACgCQABgBADAAgAOMBrQgCAAgBgBQgBgCABgCIBOjDQABgCABgCQABgDACAAQABAAABADQABACAAACIBNDEQABABgBACQgBABgDAAgAJqC5QAAgiAAgcQABgcAAgUQAAgYAJgNQAIgNASgDQAJgBAFgBQAFAAAGAAQAFAAAEgCQACgCABgEQAAgFgFgCQgFgCgIAAQgQAAgTABQgUAAgTABQgUABgOAAQgOAAgWgBQgWgBgaAAQgagBgYAAQgJAAgFACQgFACAAAFQAAAEAEACQAEACAGAAQAKAAAKAAQAKABAGABQAWAFAJAMQAIAMAAAYQABAUABAbQAAAbAAAjIAABWQAAAMgEAIQgEAJgKAFQgRAIgWABQgVACgTgBQhhgBhHgtQhJgsgnhOQgnhOgBhjQABhVAWg2QAXg3AnggQAggaAggMQAhgMAegEQAegDAZAAQA0ABApALQAqAMAcAQQAcARAOAPQASAUAGAUQAGAUABARQABAFADADQABADAFABQAFAAACgFQADgEAAgLQAAg5ABgfQADgfABgOQABgNAAgFQAAgEgCgDQgDgDgHgBQgRgBgUgDQgVgDgPgDQgKgCgagDQgagEgjgCQgigDggAAQgngBgoAEQgoAEgqANQgrANgsAaQgqAZglArQgkAqgVA7QgWA7gBBIQABBfAiBFQAhBEA8AsQA6AsBNAUQBMAVBVAAQAlAAAngEQAogEAmgJQAmgJAegPQAIgEACgGQADgGgBgRgAqDFmQAhABAkgHQAkgGAegUQAsgfATgkQASgkAAgrQAAgkgNggQgNgggegeQgfgeg1gdIghgSQgkgVgTgQQgSgRgHgQQgGgQAAgRQABgbAPgTQAPgTAZgJQAZgKAeAAQAnABAVAMQAVALAJAMQANAQAEAPQAFAPgBAGQAAAOAIAAQAFAAADgGQADgHAAgMQAAgtABgVQABgVAAgHQAAgEgCgCQgDgDgGgBQgQgEgdgEQgegEgogBQg5ABguASQguAUgbAjQgcAjAAAwQgBA0AcAqQAdAqBHApIAvAcQAjAVARATQASASAFASQAFASAAARQgBAqgdAcQgdAcg1ABQgaAAgbgHQgagIgUgRQgVgRgJgcQgEgLgCgLQgCgLAAgIQAAgEgBgEQgCgEgFgBQgFAAgCAGQgDAFAAAJQAAAHgBARQgCAQgBAVQAAAWAAAWQAAAMADAFQADAFAJAEQAbAMAiAEQAjAEAkAAgA9OB5QAAA5AAAsQgBAsgCAZQgCARgFAJQgFAJgMADQgGABgHABQgFAAgHAAIgCAAQgIAAgMgCQgPgEgUgIQglgPgggbQghgbgegeQgLgLgZgaQgZgagggiQgggjgggjQgggjgZgaQgYgcgLgOQAMgNAcgcQAcgcAgggQAhghAbgbQAbgbAMgLQAdgdAZgQQAYgQAVgIQAOgEAOgDQAPgDALAAQAGAAAEgCQADgBAAgFQAAgFgEgCQgEgBgHAAQgPAAgUAAQgTABgUAAQgTABgPAAQgNAAgSgBQgTAAgRgBQgRAAgLAAQgHAAgEABQgEACAAAFQAAAEAEACQACACAGABQAHABADAFQAEAFAAAHQgBAMgNARQgNASgUAXQgLAMgaAcQgaAbgfAgQggAhgaAcQgbAcgNAOIgFAAIAAgpQAAhEAAgmQAAglABgTQAAgTABgOQABgYAIgMQAHgNASgDQAJgBAFgBQAFgBAHAAQAGAAADgCQAEgBAAgFQAAgFgFgCQgFgBgJAAQgQAAgWAAQgWABgUAAQgUABgMAAQgLAAgVgBQgVAAgZgBQgaAAgZAAQgKAAgFABQgFACAAAFQAAAFAEABQAEACAIAAQAKAAAKABQAKABAGABQAWAEAIANQAIAMABAXQABAOABATQAAATAAAlQAAAmAABEIAAChQAABAAAA0QgBAygDAeQgDAVgFANQgGAOgNADQgGABgJABQgIABgKAAQgIAAgEACQgDACAAAEQAAAEAFADQAFACAJAAQASAAAXgBQAXAAAUgBQAUgBALAAQAMAAAWABQAVABAaAAQAaABAaAAQAIAAAFgCQAEgDAAgEQAAgEgDgCQgDgCgGAAQgJAAgNgBQgNgBgKgBQgRgDgHgOQgHgNgCgUQgCgeAAgzQgBg0AAhAIAAhSIAFAAIAKAMQAHAJAWAbQAWAaAfAkQAfAkAgAlQAfAkAaAcQAbAdAMALQATASARANQARAMATAHQASAIAYACQAPABAOAAQAOABAVAAIBQAAQADAAADAAQABAAACAAQAQAAAWgBQAVAAATgBQASgBAKAAQARAAAkACQAkABAqAAQAGAAAFgCQAEgCAAgFQAAgCgDgDQgDgDgHAAQgJAAgMAAQgMgBgIgBQgSgDgGgJQgHgJgBgQQgDgZgBgtQAAgsAAg5IAAiJQAAg7AAggQAAgfAAgQQABgQABgMQABgUAGgKQAHgKAQgCQAHgCAFgBQAGAAAGAAQAGAAAEgCQADgCAAgFQAAgEgFgBQgEgCgHAAQgRAAgUABQgUAAgSABQgTAAgLAAQgMAAgTAAQgUgBgVAAQgVgBgPAAQgKAAgFACQgFABAAAEQABAFADACQADACAGAAQAIAAAIABQAHABAHACQANADAGAKQAHAJABATQABAMAAAQQAAAQAAAfQAAAgAAA7gA1rgcQAAgfAAgeQAAgeAAgYQABgYAAgOQAAgHADgDQACgEAFgCQAGgDAPgBQAQgBANAAQAggBAnAFQAmAFAoAQQAoARAmAgQASAQARAbQARAbALAmQAMAlAAAyQAAA9gPAyQgPAygnAhQgkAegrAMQgrAMg3gBQgvAAgZgKQgagKgIgLQgEgHgCgRQgCgQgBgPQgBgNAAgpQgBgqAAg/gA3XB5QAAA2gBAsQAAArgDAZQgCARgFALQgFALgMADQgFABgHABQgHAAgJAAQgIAAgDADQgCADAAACQAAAFAEACQAEACAHAAQANAAAPgBQAOAAAOgBQAPAAAMAAQANgBAHAAQAPAAAVACQAVABAYACQAZACAZABQAZACAWAAQBLgBA2gPQA1gPAkgVQAjgVASgTQAYgXAUggQAUggAMgpQAMgpABgxQgBhFgWgyQgWgxgfgeQgtgsg5gTQg4gTg7gFQg6gEgzABQgZAAgZABQgaAAgWABQgVAAgNAAQgLAAgUAAQgTgBgXAAQgWgBgWAAQgJAAgEACQgFABAAAFQAAAEAEACQAEACAGAAQAJAAAJAAQAJABAFACQATAFAHAJQAIAJABATQAAAMABAQQAAAQAAAfQAAAgAAA7g");
	this.shape_66.setTransform(569.2,131.8972);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FEDD7C").s().p("ADfFUQhMgUg7gsQg8gsghhEQgihFgBhfQABhIAWg7QAWg7AjgqQAlgrAqgZQAsgaArgNQApgNApgEQAogEAnABQAhAAAhADQAjACAaAEIAkAFIAkAGQAUADARABQAHABADADQACADAAAEIgBASIgDAtIgCBYQABALgEAEQgCAFgFAAQgFgBgBgDIgEgIQgBgRgGgUQgGgUgSgUQgOgPgcgRQgcgQgpgMQgqgLg0gBQgaAAgdADQgeAEghAMQggAMggAaQgnAggXA3QgWA2AABVQAABjAnBOQAoBOBHAsQBJAtBgABQATABAWgCQAVgBARgIQAKgFAEgJQAEgIAAgMIAAhWIAAg+IgBgvQAAgYgJgMQgJgMgWgFIgPgCIgVAAQgGAAgEgCQgEgCAAgEQAAgFAFgCQAFgCAKAAIAxABIAwABIAkABIAigBIAngBIAjgBQAIAAAFACQAFACAAAFQAAAEgEACQgDACgFAAIgLAAIgNACQgTADgIANQgIANgBAYIAAAwIAAA+IAABmQAAARgDAGQgCAGgIAEQgeAPglAJQgnAJgoAEQgnAEgkAAQhWAAhMgVgAqDFmQgkAAgigEQgjgEgagMQgKgEgDgFQgDgFAAgMIAAgsIADglIACgYQAAgJACgFQADgGAFAAQAEABACAEIACAIQAAAIACALIAFAWQAKAcAUARQAVARAaAIQAaAHAaAAQA1gBAegcQAdgcAAgqQAAgRgFgSQgFgSgSgSQgRgTgjgVIgvgcQhHgpgdgqQgcgqABg0QAAgwAcgjQAbgjAugUQAvgSA4gBQAoABAeAEQAdAEAQAEQAGABADADQADACAAAEIgCAcIgBBCQAAAMgDAHQgDAGgFAAQgHAAgBgOQABgGgEgPQgFgPgNgQQgIgMgWgLQgVgMgngBQgdAAgZAKQgaAJgPATQgPATAAAbQgBARAGAQQAHAQASARQATAQAkAVIAhASQA1AdAfAeQAeAeANAgQAOAggBAkQAAArgSAkQgTAkgsAfQgeAUgkAGQghAGgfAAIgFAAgA0jFhIgygDIgtgDIgkgCIgUABIgaAAIgdABIgbABQgIAAgDgCQgFgCAAgFQAAgCACgDQAEgDAHAAIAQAAIANgCQALgDAGgLQAEgLACgRQADgZABgrIAAhiIAAiJIAAhbIAAgvIgBgcQgBgTgHgJQgIgJgTgFIgOgDIgSAAQgGAAgEgCQgEgCABgEQgBgFAFgBQAEgCAKAAIAsABIApABIAgAAIAhAAIAwgBIAygBQA0gBA5AEQA7AFA4ATQA5ATAtAsQAfAeAWAxQAXAyAABFQgBAxgLApQgNApgUAgQgUAggYAXQgSATgjAVQgjAVg2APQg2APhKABQgXAAgZgCgA0tjKIgeABQgPABgGADQgFACgCAEQgDADABAHIgBAmIAAA2IAAA9IAABhIAABpIABA2IADAfQACARAEAHQAIALAaAKQAZAKAwAAQA3ABAqgMQArgMAkgeQAnghAPgyQAQgygBg9QAAgygLglQgMgmgQgbQgSgbgSgQQgmgggogRQgogQgmgFQgjgFgeAAIgFABgEAolAFeIhSgBIhDgCIg1gBIgogBIgUABIgbAAIgdABIgbABQgHAAgEgCQgEgCAAgFQAAgCACgDQADgDAIAAIAQAAIAMgCQAMgDAFgLQAFgKACgSQADgZAAgrIAAhiIAAiJIAAhaIAAgwIgBgcQgBgTgHgJQgHgJgUgFIgNgDIgSAAQgGAAgFgCQgDgCAAgEQAAgFAFgBQAEgCAJAAIAsABIAqABIAfAAIAgAAIA0ABIA8AAIAzAAIAagBIAUgCIANgDIAHgCIAHgBQAAAAABAAQABAAAAAAQABAAAAABQABAAAAABIABAFIgCAOQgDAKgBAbIgBAPIgCAVIgCAPIgCAIQgCAFgFAAQgEAAgBgCIgCgIIgBgNQAAgIgEgHQgEgLgKgHQgKgIgdgDIgYgCIgnAAIgngBIgZgBQgBAAgBAAQAAAAgBABQAAAAgBAAQAAABgBAAQgBACAAADIAADBIABAGQACADADAAIAbAAIAsAAIArgBIAcgBQAOgCAJgCQAJgDAGgEIAIgIQACgCADAAQADAAACACQABACAAAEQAAADgBALIgFAqIgCATIgBAVIgBAMIgBALQgCAGgFABQgFAAgBgCQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBIAAgNIgCgPQgDgMgLgIQgJgIgWgDIgYgBIgmgBIgngBIgaAAQgBAAgBAAQAAAAgBAAQAAAAAAABQgBAAAAABIgBAGIAAA/IAAAlIAAAsIAAAjQAAAnAZANQAXAOA+gBQARAAAVgCQAVgCARgGQAPgHAIgOQAIgNAEgYQABgGACgDQACgDAEAAQAFAAABAGQACAGAAAGIgDAbQgBARgDARQgCARgDAJQgDAOgJADQgHADgSAAIgGAAgEAhKAFdIgygBIgzgBIglgCQgOgBgFgCQgFgDABgDQgBgDADgCIAHgDQADgCABgHQACgIgDgRIgtlQIgCAAIiuFZQgOAbgGAJQgHAIgGAAQgHAAgIgLIgRgcIgVgoIgdg2Igbg0QgMgXgEgJIgSglIgfhAIggg+IgCAAIgnEtIgCASIgBATQAAALAHAFQAHAFALACIARACIALABQAGAAADADQAEACABADQgBAFgFACQgEACgKAAIgygBIgjgCIglACIgsABIgJgBIgbABIg+gBIhcgBIgSgBQgGgCgBgEQAAgDACgCQACgCAGgBQAFgBADgEQACgFgCgHIg/ieIgDgFIgFgBIi/AAIgEABIgDAFIgrBqQgGAOgDANQgDANAAAHQgBALAIAFQAHAGATAAIALAAQAIAAACADQACACAAADQABAFgEACQgDACgHAAIgtgBIgsgCIgjACIg8ABQgHAAgEgCQgDgCAAgFQgBgDADgCQACgDAFAAIAMAAIAMgBQAagEAPgRQAOgSAMgdIDTnoQAHgRAGgHQAGgHAFAAQAJAAAFAFQAEAGAHANIAXA3IAqBiIA0B2IAxB0IAoBbQAPAjANASQAMARALAGQAKAHAHABIAQACIAPAAIAFABIAFgBIAKAAIAPgBQAPgEAIgSQAHgSACgUIBQn6QACgKAFgFQAFgGAFAAQAFAAAFAFQAGAFAIAPIDZGwIDam1QAEgKAGgFQAFgFAFAAQAFAAAGAHQAFAGADAMIBJHhQAFAkAJASQAIASASAFQARAEALACIASABQAGAAADACQAEACAAADQgBAFgFACQgGADgJAAIgegBgAPZhhIgCAEIhNDDQgBAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAAAAAABQABAAAAAAQAAAAABAAICcAAQABAAABAAQAAAAABAAQAAgBAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIhNjEIgBgEQAAgBAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQAAAAgBAAQAAAAAAABQgBAAAAAAQAAABgBABgA7jFbIg2gCIgcABIgoABIgmABIgDAAIgGAAIhQAAIgjgBIgdgBQgYgCgSgIQgSgHgRgMQgSgNgSgSQgNgLgbgdQgZgcgggkIg/hJIg1g+IgcgkIgLgMIgFAAIAABSIABB0QABAzABAeQACAUAHANQAHAOARADIAYACIAVABQAHAAACACQADACAAAEQABAEgFADQgFACgIAAIg0gBIgvgBIghgBIggABIgqABIgqABQgJAAgFgCQgEgDAAgEQAAgEACgCQAEgCAIAAIATgBIAOgCQANgDAGgOQAFgNADgVQADgeABgyIABh0IAAihIAAhqIgBg4IgCghQgBgXgIgMQgIgNgWgEIgQgCIgUgBQgIAAgDgCQgFgBAAgFQABgFAFgCQAEgBALAAIAyAAIAuABIAhABIAfgBIAqgBIAmAAQAJAAAGABQAEACAAAFQAAAFgEABQgDACgGAAIgMABIgOACQgSADgHANQgIAMgBAYIgBAhIgBA4IAABqIAAApIAFAAIAogqIA6g9IA6g7IAkgoQAUgXAOgSQANgRAAgMQAAgHgDgFQgDgFgHgBQgHgBgCgCQgEgCAAgEQAAgFAEgCQAEgBAIAAIAbAAIAkABIAfABIAigBIAogBIAiAAQAHAAAFABQADACAAAFQABAFgEABQgDACgHAAQgLAAgOADQgPADgNAEQgWAIgYAQQgZAQgdAdIgnAmIg7A8Ig9A8IgoApIAkAqIA4A9IBABGIA5A8IAkAlQAfAeAgAbQAgAbAlAPQAVAIAOAEIAUACIACAAIANAAIAMgCQAMgDAFgJQAFgJACgRQADgZAAgsIAAhlIAAiJIAAhbIAAgvIgBgcQAAgTgIgJQgGgKgNgDIgOgDIgPgBQgHAAgDgCQgDgCgBgFQAAgEAGgBQAEgCAKAAIAkABIApABIAfAAIAeAAIAmgBIAlgBQAHAAAEACQAFABAAAEQAAAFgDACQgDACgHAAIgMAAIgLADQgRACgHAKQgGAKgBAUIgCAcIAAAvIAABbIAACJIAABlQABAtADAZQACAQAGAJQAGAJASADIAUACIAWAAQAGAAAEADQACADAAACQAAAFgEACQgFACgGAAIhNgBg");
	this.shape_67.setTransform(569.2,131.8972);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FEDD7C").s().p("ACfEsIhSgBIhCgCIg0gBIgpgBIgUABIgbAAIgcABIgcABQgHAAgEgCQgEgCAAgFQAAgCACgDQADgDAIAAIAQAAIAMgCQAMgDAFgLQAFgKACgSQADgZAAgrIABhiIAAiJIAAhaIAAgwIgBgcQgBgTgIgJQgHgJgTgFIgOgDIgSAAQgGAAgEgCQgEgCAAgEQAAgFAFgBQAEgCAJAAIAsABIAqABIAfAAIAgAAIA0ABIA7AAIAzAAIAagBIAUgCIAOgDIAHgCIAGgBQABAAAAAAQABAAABAAQAAABABAAQAAAAAAABIABAFIgCAOQgDAKgBAbIgBAPIgCAVIgBAPIgDAIQgCAFgFAAQgEAAgBgCIgBgIIgBgNQgBgIgEgHQgEgLgJgHQgLgIgdgDIgXgCIgnAAIgogBIgYgBQgBAAAAABQgBAAgBAAQAAAAAAABQgBAAAAAAQgCACAAADIAADCIABAGQACADADAAIAaAAIAsAAIArgBIAcgBQAOgCAJgCQAJgDAGgFIAIgIQACgCADAAQADAAACACQABACAAAEQABADgCAMIgFApIgCATIgBAVIgBAMIgBALQgCAGgFABQgEAAgBgCQgBgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBIgBgNIgCgPQgDgMgKgIQgKgIgWgDIgXgBIgmgBIgogBIgZAAQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABgBAAIgBAGIAAA/IAAAlIAAAsIAAAjQAAAnAYANQAYAOA9gBQARAAAVgCQAVgCARgGQAPgHAIgOQAIgNAEgYQABgGACgDQACgDAEAAQAFAAABAGQACAGAAAGIgCAbQgCARgDARQgCARgCAJQgEAOgJADQgHADgSAAIgGAAg");
	this.shape_68.setTransform(811.625,134.9036);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FEDD7C").s().p("AFwEvIgygBIgzgBIglgCQgOgBgFgCQgFgDAAgDQAAgDADgCIAGgDQAEgCABgHQABgIgCgRIgtlQIgDAAIitFZQgNAbgGAJQgHAIgGAAQgHAAgIgLIgRgcIgVgoIgdg2Igbg0QgMgXgEgJIgSglIggg/Igfg/IgDAAIgmEtIgCASIgBATQAAALAHAFQAHAFALACIARACIALABQAGAAADADQAEACAAADQAAAFgFACQgFACgJAAIgygBIgkgCIgkACIgsABQgGAAgEgCQgFgCAAgFQAAgDAEgCQADgDAGAAIAKAAIAPgBQAQgEAIgSQAHgSACgUIBQn6QACgKAFgFQAEgGAFAAQAGAAAFAFQAGAFAIAPIDZGwIDYm1QAFgKAGgFQAFgFAFAAQAFAAAGAHQAFAGADAMIBJHhQAFAkAIASQAJASASAFQARAEALACIASABQAGAAADACQAEACAAADQgBAFgGACQgFADgJAAIgegBg");
	this.shape_69.setTransform(743.275,134.5227);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FEDD7C").s().p("ADwEuIhcgBIgSgBQgGgBAAgEQAAgEACgCQACgBAGgBQAEgBADgFQADgFgDgHIg+ieIgEgEIgFgBIi9AAIgFABIgCAEIgsBqQgGAPgDAMQgDAOAAAGQAAALAHAFQAHAGATABIALAAQAIAAACACQADADAAADQAAAEgEACQgDACgHAAIgtgBIgsgCIgiACIg8ABQgIAAgDgCQgEgCAAgEQAAgDACgDQACgCAFAAIAMgBIAMAAQAbgFAOgRQAOgRAMgeIDUnoQAGgQAGgIQAGgHAGAAQAHAAAFAGQAFAFAGAOIAYA2IAqBjIAzB2IAxBzIAoBbQAPAjANASQANASAKAGQAKAGAIABIAQACIAOABQALAAAAAIQAAAEgGACQgHACgWAAIg/gBgAgZiOIgCAEIhODDQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAQABAAAAAAQABABAAAAICcAAQAAAAABgBQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAQgBgBAAAAIhLjEIgBgEQgBgBAAAAQAAgBAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAABg");
	this.shape_70.setTransform(669.025,134.4);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FEDD7C").s().p("AhlFUQhNgUg7gsQg7gsgihEQgihFgBhfQABhIAWg7QAWg7AkgqQAlgrAqgZQAsgaArgNQApgNApgEQAngEAnABQAgAAAiADQAiACAbAEIAkAFIAkAGQAUADAQABQAIABADADQACADAAAEIgBASIgEAtIgBBYQAAALgDAEQgCAFgFAAQgFgBgCgDIgDgIQgBgRgGgUQgGgUgSgUQgOgPgcgRQgdgQgpgMQgpgLg0gBQgaAAgcADQgeAEghAMQggAMggAaQgnAggXA3QgWA2gBBVQABBjAnBOQAnBOBIAsQBIAtBgABQATABAVgCQAWgBARgIQAKgFAEgJQAEgIgBgMIAAhWIAAg+IgBgvQAAgYgIgMQgJgMgWgFIgQgCIgUAAQgGAAgEgCQgEgCAAgEQAAgFAFgCQAFgCAJAAIAyABIAwABIAkABIAigBIAmgBIAjgBQAJAAAFACQAFACAAAFQgBAEgDACQgDACgFAAIgLAAIgOACQgSADgIANQgJANAAAYIgBAwIAAA+IAABmQABARgDAGQgCAGgIAEQgeAPgmAJQgmAJgoAEQgnAEglAAQhUAAhMgVg");
	this.shape_71.setTransform(600.375,129.9472);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FEDD7C").s().p("AgiEyQgkAAgigEQgjgEgagMQgKgEgDgFQgDgFAAgMIABgsIACglIACgYQAAgJACgFQADgGAFAAQAFABACAEIABAIQAAAIACALIAFAWQAKAcAUARQAVARAaAIQAaAHAaAAQA0gBAegcQAdgcAAgqQABgRgGgSQgFgSgRgSQgRgTgkgVIgugcQhHgogcgrQgdgqABg0QABgwAbgjQAbgjAvgUQAugSA3gBQAoABAeAEQAeAEAQAEQAFABADADQADACAAAEIgCAcIgBBCQAAAMgDAHQgCAGgFAAQgIAAAAgOQAAgGgEgPQgFgPgNgQQgIgMgWgLQgVgMgngBQgdAAgYAKQgZAJgQATQgPATAAAbQgBARAHAQQAGAQATARQATAQAiAVIAhASQA1AeAfAeQAfAdANAgQANAggBAkQABArgTAkQgTAkgrAfQgfAUgjAGQgiAHgeAAIgFgBg");
	this.shape_72.setTransform(506.9009,135.1018);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FEDD7C").s().p("AhIEpIgxgDIgtgDIglgBIgTAAIgbABIgdABIgbAAQgIAAgDgCQgEgCAAgEQgBgDADgCQADgDAHAAIAQgBIANgCQAMgDAFgKQAFgLACgRQACgaABgrIAAhhIAAiKIAAhaIAAgwIgBgcQgBgTgHgJQgIgJgTgFIgOgCIgSAAQgGAAgEgDQgDgBAAgFQAAgEAEgBQAFgCAJAAIAsAAIAqABIAfABIAigBIAvgBIAyAAQA0gBA5AEQA6AEA5ATQA4ATAtAsQAfAeAWAyQAXAxAABGQAAAwgMAqQgNAogUAgQgUAhgXAWQgSATgkAWQgjAVg2AOQg2APhJABQgXAAgZgCgAhSkCIgdACQgPABgGADQgGACgCADQgCAEAAAGIgBAmIAAA2IAAA+IAABhIAABoIACA2IACAgQACARAFAGQAHAMAaAKQAaAJAvABQA2AAAqgMQArgMAkgeQAnggAQgzQAPgyAAg9QgBgxgLgmQgLgmgRgbQgSgagSgQQgmghgogQQgogQglgFQgjgFgdAAIgGAAg");
	this.shape_73.setTransform(443.525,135.465);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FEDD7C").s().p("AAqEnIg1gCIgcABIgnABIgmABQgIAAgEgCQgEgCAAgFQAAgCACgDQADgDAIAAIAQAAIANgCQALgDAFgJQAGgJABgRQADgZABgsIAAhlIAAiJIAAhbIAAgvIgBgcQgBgTgHgJQgGgKgOgDIgNgDIgQgBQgGAAgEgCQgDgCAAgFQAAgEAFgBQAFgCAKAAIAkABIAoABIAgAAIAcAAIAngBIAlgBQAHAAAEACQAFABgBAEQAAAFgCACQgEACgGAAIgMAAIgMADQgQACgHAKQgGAKgBAUIgCAcIAAAvIAABbIAACJIAABlQAAAtADAZQACAQAHAJQAGAJASADIAUACIAVAAQAGAAAEADQADADAAACQAAAFgFACQgEACgHAAIhNgBg");
	this.shape_74.setTransform(387.2,135.125);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FEDD7C").s().p("AEMFbIgjAAIgcgBQgZgCgSgIQgSgIgRgLQgRgNgTgSQgNgMgagcQgagcgfgkIg/hJIg1g+IgcgkIgLgNIgEAAIAABTIAABzQABA0ACAdQABAVAHANQAIAOARADIAXACIAWABQAGAAADACQADACAAAEQAAAEgFADQgFABgIAAIg0AAIgvgBIghgBIggABIgqABIgqAAQgJAAgFgBQgEgDAAgEQAAgEADgCQADgCAIAAIATgBIAOgCQAOgDAFgOQAGgNACgWQADgdABgzIABhzIAAihIAAhqIgBg5IgBggQgBgXgIgMQgJgNgWgEIgPgCIgVgBQgHAAgEgCQgEgBAAgFQAAgFAFgCQAFgCAKABIAyAAIAuABIAhABIAggBIAqgBIAlAAQAKgBAFACQAFACAAAFQAAAFgEABQgEACgFAAIgNABIgNACQgSADgIANQgHAMgBAYIgCAgIAAA5IAABqIAAApIAEAAIAogqIA6g9IA6g7IAkgpQAUgWANgSQANgRAAgMQAAgHgDgFQgDgFgHgBQgGgCgDgCQgDgCAAgDQAAgFADgCQAEgCAIABIAcAAIAjABIAfABIAjgBIAngBIAiAAQAHgBAFACQAEACAAAFQAAAFgEABQgDACgHAAQgKAAgPADQgPADgNAEQgVAIgZAQQgYAQgeAdIgmAmIg8A7Ig7A9IgpAoIAkAqIA3A+IBABGIA5A8IAlAlQAeAdAgAcQAgAbAlAPQAVAIAOAEQAOACAIAAQAFAAAEACQADABAAAFQAAAEgEADQgFABgNAAg");
	this.shape_75.setTransform(339.725,129.95);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#7B1E00").s().p("ACfEsIhSgBIhCgCIg0gBIgpgBIgUABIgbAAIgcABIgcABQgHAAgEgCQgEgCAAgFQAAgCACgDQADgDAIAAIAQAAIAMgCQAMgDAFgLQAFgKACgSQADgZAAgrIABhiIAAiJIAAhaIAAgwIgBgcQgBgTgIgJQgHgJgTgFIgOgDIgSAAQgGAAgEgCQgEgCAAgEQAAgFAFgBQAEgCAJAAIAsABIAqABIAfAAIAgAAIA0ABIA7AAIAzAAIAagBIAUgCIAOgDIAHgCIAGgBQABAAAAAAQABAAABAAQAAABABAAQAAAAAAABIABAFIgCAOQgDAKgBAbIgBAPIgCAVIgBAPIgDAIQgCAFgFAAQgEAAgBgCIgBgIIgBgNQgBgIgEgHQgEgLgJgHQgLgIgdgDIgXgCIgnAAIgogBIgYgBQgBAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQgCACAAADIAADCIABAGQACADADAAIAaAAIAsAAIArgBIAcgBQAOgCAJgCQAJgDAGgFIAIgIQACgCADAAQADAAACACQABACAAAEQABADgCAMIgFApIgCATIgBAVIgBAMIgBALQgCAGgFABQgEAAgBgCQgBgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBIgBgNIgCgPQgDgMgKgIQgKgIgWgDIgXgBIgmgBIgogBIgZAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgBABAAAAIgBAGIAAA/IAAAlIAAAsIAAAjQAAAnAYANQAYAOA9gBQARAAAVgCQAVgCARgGQAPgHAIgOQAIgNAEgYQABgGACgDQACgDAEAAQAFAAABAGQACAGAAAGIgCAbQgCARgDARQgCARgCAJQgEAOgJADQgHADgSAAIgGAAg");
	this.shape_76.setTransform(812.375,140.3036);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#7B1E00").s().p("AFwEvIgygBIgzgBIglgCQgOgBgFgCQgFgDAAgDQAAgDADgCIAGgDQAEgCABgHQABgIgCgRIgtlQIgDAAIitFZQgNAbgGAJQgHAIgGAAQgHAAgIgLIgRgcIgVgoIgdg2Igbg0QgMgXgEgJIgSglIggg/Igfg/IgDAAIgmEtIgCASIgBATQAAALAHAFQAHAFALACIARACIALABQAGAAADADQAEACAAADQAAAFgFACQgFACgJAAIgygBIgkgCIgkACIgsABQgGAAgEgCQgFgCAAgFQAAgDAEgCQADgDAGAAIAKAAIAPgBQAQgEAIgSQAHgSACgUIBQn6QACgKAFgFQAEgGAFAAQAGAAAFAFQAGAFAIAPIDZGwIDYm1QAFgKAGgFQAFgFAFAAQAFAAAGAHQAFAGADAMIBJHhQAFAkAIASQAJASASAFQARAEALACIASABQAGAAADACQAEACAAADQgBAFgGACQgFADgJAAIgegBg");
	this.shape_77.setTransform(744.025,139.9227);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#7B1E00").s().p("ADwEuIhcgBIgSgBQgGgBAAgEQAAgEACgCQACgBAGgBQAEgBADgFQADgFgDgHIg+ieIgEgEIgFgBIi9AAIgFABIgCAEIgsBqQgGAPgDAMQgDAOAAAGQAAALAHAFQAHAGATABIALAAQAIAAACACQADADAAADQAAAEgEACQgDACgHAAIgtgBIgsgCIgiACIg8ABQgIAAgDgCQgEgCAAgEQAAgDACgDQACgCAFAAIAMgBIAMAAQAbgFAOgRQAOgRAMgeIDUnoQAGgQAGgIQAGgHAGAAQAHAAAFAGQAFAFAGAOIAYA2IAqBjIAzB2IAxBzIAoBbQAPAjANASQANASAKAGQAKAGAIABIAQACIAOABQALAAAAAIQAAAEgGACQgHACgWAAIg/gBgAgZiOIgCAEIhODDQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAQABAAAAAAQABABAAAAICcAAQAAAAABgBQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAQgBgBAAAAIhLjEIgBgEQgBgBAAAAQAAgBAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBABQAAAAAAABg");
	this.shape_78.setTransform(669.775,139.8);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#7B1E00").s().p("AhlFUQhNgUg7gsQg7gsgihEQgihFgBhfQABhIAWg7QAWg7AkgqQAlgrAqgZQAsgaArgNQApgNApgEQAngEAnABQAgAAAiADQAiACAbAEIAkAFIAkAGQAUADAQABQAIABADADQACADAAAEIgBASIgEAtIgBBYQAAALgDAEQgCAFgFAAQgFgBgCgDIgDgIQgBgRgGgUQgGgUgSgUQgOgPgcgRQgdgQgpgMQgpgLg0gBQgaAAgcADQgeAEghAMQggAMggAaQgnAggXA3QgWA2gBBVQABBjAnBOQAnBOBIAsQBIAtBgABQATABAVgCQAWgBARgIQAKgFAEgJQAEgIgBgMIAAhWIAAg+IgBgvQAAgYgIgMQgJgMgWgFIgQgCIgUAAQgGAAgEgCQgEgCAAgEQAAgFAFgCQAFgCAJAAIAyABIAwABIAkABIAigBIAmgBIAjgBQAJAAAFACQAFACAAAFQgBAEgDACQgDACgFAAIgLAAIgOACQgSADgIANQgJANAAAYIgBAwIAAA+IAABmQABARgDAGQgCAGgIAEQgeAPgmAJQgmAJgoAEQgnAEglAAQhUAAhMgVg");
	this.shape_79.setTransform(601.125,135.3472);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#7B1E00").s().p("AgiEyQgkAAgigEQgjgEgagMQgKgEgDgFQgDgFAAgMIABgsIACglIACgYQAAgJACgFQADgGAFAAQAFABACAEIABAIQAAAIACALIAFAWQAKAcAUARQAVARAaAIQAaAHAaAAQA0gBAegcQAdgcAAgqQABgRgGgSQgFgSgRgSQgRgTgkgVIgugcQhHgogcgrQgdgqABg0QABgwAbgjQAbgjAvgUQAugSA3gBQAoABAeAEQAeAEAQAEQAFABADADQADACAAAEIgCAcIgBBCQAAAMgDAHQgCAGgFAAQgIAAAAgOQAAgGgEgPQgFgPgNgQQgIgMgWgLQgVgMgngBQgdAAgYAKQgZAJgQATQgPATAAAbQgBARAHAQQAGAQATARQATAQAiAVIAhASQA1AeAfAeQAfAdANAgQANAggBAkQABArgTAkQgTAkgrAfQgfAUgjAGQgiAHgeAAIgFgBg");
	this.shape_80.setTransform(507.6509,140.5018);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#7B1E00").s().p("AhIEpIgxgDIgtgDIglgBIgTAAIgbABIgdABIgbAAQgIAAgDgCQgEgCAAgEQgBgDADgCQADgDAHAAIAQgBIANgCQAMgDAFgKQAFgLACgRQACgaABgrIAAhhIAAiKIAAhaIAAgwIgBgcQgBgTgHgJQgIgJgTgFIgOgCIgSAAQgGAAgEgDQgDgBAAgFQAAgEAEgBQAFgCAJAAIAsAAIAqABIAfABIAigBIAvgBIAyAAQA0gBA5AEQA6AEA5ATQA4ATAtAsQAfAeAWAyQAXAxAABGQAAAwgMAqQgNAogUAgQgUAhgXAWQgSATgkAWQgjAVg2AOQg2APhJABQgXAAgZgCgAhSkCIgdACQgPABgGADQgGACgCADQgCAEAAAGIgBAmIAAA2IAAA+IAABhIAABoIACA2IACAgQACARAFAGQAHAMAaAKQAaAJAvABQA2AAAqgMQArgMAkgeQAnggAQgzQAPgyAAg9QgBgxgLgmQgLgmgRgbQgSgagSgQQgmghgogQQgogQglgFQgjgFgdAAIgGAAg");
	this.shape_81.setTransform(444.275,140.865);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#7B1E00").s().p("AAqEnIg0gCIgcABIgpABIgmABQgHAAgDgCQgFgCAAgFQAAgCADgDQADgDAHAAIAQAAIANgCQALgDAGgJQAEgJADgRQACgZABgsIAAhlIAAiJIAAhbIAAgvIgBgcQgBgTgHgJQgGgKgNgDIgPgDIgPgBQgGAAgEgCQgCgCgBgFQAAgEAFgBQAFgCAJAAIAlABIApABIAfAAIAdAAIAmgBIAlgBQAHAAAEACQAFABAAAEQAAAFgEACQgDACgGAAIgMAAIgMADQgRACgGAKQgHAKgBAUIgBAcIgBAvIAABbIAACJIABBlQABAtACAZQACAQAGAJQAHAJASADIAUACIAVAAQAHAAADADQADADAAACQgBAFgDACQgFACgHAAIhNgBg");
	this.shape_82.setTransform(387.95,140.525);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#7B1E00").s().p("AEMFbIgjAAIgcgBQgZgCgSgIQgSgIgRgLQgRgNgTgSQgNgMgagcQgagcgfgkIg/hJIg1g+IgcgkIgLgNIgEAAIAABTIAABzQABA0ACAdQABAVAHANQAIAOARADIAXACIAWABQAGAAADACQADACAAADQAAAFgFADQgFABgIAAIg0AAIgvgBIghgBIggABIgqABIgqAAQgJAAgFgBQgEgDAAgFQAAgDADgCQADgCAIAAIATgBIAOgCQAOgDAFgOQAGgNACgWQADgdABgzIABhzIAAihIAAhqIgBg5IgBggQgBgXgIgMQgJgNgWgEIgPgCIgVgBQgHAAgEgCQgEgBAAgFQAAgFAFgCQAFgCAKABIAyAAIAuABIAhABIAggBIAqgBIAlAAQAKgBAFACQAFACAAAFQAAAFgEABQgEACgFAAIgNABIgNACQgSADgIANQgHAMgBAYIgCAgIAAA5IAABqIAAApIAEAAIAogqIA6g9IA6g7IAkgpQAUgWANgSQANgRAAgMQAAgHgDgFQgDgFgHgBQgGgCgDgCQgDgCAAgDQAAgFADgCQAEgCAIABIAcAAIAjABIAfABIAjgBIAngBIAiAAQAHgBAFACQAEACAAAFQAAAFgEABQgDACgHAAQgKAAgPADQgPADgNAEQgVAIgZAQQgYAQgeAdIgmAmIg8A7Ig7A9IgpAoIAkAqIA3A+IBABGIA5A8IAlAlQAeAdAgAcQAgAbAlAPQAVAIAOAEQAOACAIAAQAFAAAEACQADABAAAEQAAAFgEADQgFABgNAAg");
	this.shape_83.setTransform(340.475,135.35);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#FFFFFF").ss(31,1,1).p("EAkBAB5QAAA2AAAsQgBArgCAZQgCASgFAKQgFALgMADQgFABgIABQgHAAgJAAQgHAAgDADQgCADAAACQAAAFAEACQADACAIAAQAMAAAPgBQAPAAAOgBQAPAAAMAAQANgBAGAAQASAAAXABQAXAAAeABQAeABAlABQAlABAtAAQAWAAAJgDQAJgDADgOQADgJACgRQADgRABgRQADgRAAgKQAAgGgCgGQgCgGgEAAQgEAAgCADQgCADgBAGQgEAYgIANQgIAOgPAHQgRAGgVACQgWACgQAAQg9ABgZgOQgYgNAAgnQAAgNAAgWQAAgWAAgWQAAgXAAgOIAAg/QAAgEABgCQABgCACAAQAJAAASAAQASAAAVABQAVABASAAQAQABAHAAQAWADAKAIQAKAIADAMQABAIABAHQAAAHAAAGQAAADACACQACACAEAAQAFgBACgGQABgGAAgFQAAgDAAgJQABgKABgLQABgLABgIQAEgdABgNQABgLAAgDQAAgEgBgCQgDgCgCAAQgDAAgCACQgEAEgEAEQgGAEgJADQgKACgNACQgIAAgUABQgUAAgYABQgXAAgUAAQgTAAgJAAQgCAAgCgDQgBgCAAgEIAAjBQAAgDABgCQACgCACAAQAIAAASABQASAAAVABQAWAAARAAQASABAGABQAdADALAIQAJAHAEALQADAHABAIQABAIAAAFQAAAFACADQABACAEAAQAFAAABgFQACgFACgDQAAgFABgKQABgLAAgKQABgLABgEQABgbADgKQACgLAAgDQAAgDgBgCQgBgCgDAAQgDAAgEABQgCABgFABQgFABgIACQgJABgMABQgFABgVAAQgVAAgdAAQgeAAgeAAQgegBgXAAQgWAAgJAAQgLAAgUAAQgUgBgWAAQgXgBgVAAQgJAAgFACQgEABAAAFQAAAEAEACQAEACAGAAQAJAAAIAAQAJABAFACQATAFAIAJQAHAJABATQABAMAAAQQAAAQAAAgQAAAfAAA7gAQ6CWQACAAADABQACACABADIA/CeQACAHgCAFQgDAEgFABQgGABgBACQgDACAAADQAAAEAHACQAGABALAAQA0ABApAAQApABAVAAQATAAAIgBQAEABAFAAQAUAAAYgBQAYgCAMAAQAMAAAYACQAYABAaAAQAJAAAFgCQAFgCAAgFQAAgDgEgCQgDgDgFAAQgGAAgGgBQgHAAgKgCQgLgCgHgFQgHgFAAgLQAAgKABgJQAAgIACgKIAmktIADAAQAOAcARAiQASAjAOAdQAOAdAEAIQAEAJAMAXQAMAXAPAdQAPAcAOAaQANAZAIAPQAKARAHALQAIALAHAAQAGAAAHgIQAGgJANgbICulZIADAAIAtFQQACARgBAIQgBAHgEACQgEABgCACQgDACAAADQAAADAFADQAFACAOABQANABAYABQAYAAAcABQAbABAWAAQAVABAJAAQAJAAAGgDQAGgCAAgFQAAgDgEgCQgDgCgGAAQgHAAgLgBQgLgCgRgEQgSgFgIgSQgJgSgFgkIhJnhQgDgMgFgGQgFgHgFAAQgGAAgFAFQgGAFgFAKIjZG1IjZmwQgIgPgGgFQgFgFgFAAQgFAAgFAGQgFAFgCAKIhQH6QgCAUgHASQgIASgQAEQgJABgGAAQgFAAgFAAQgCAAgCABQgDgBgDAAQgGAAgIAAQgGgBgKgBQgHgBgKgHQgLgGgMgRQgNgSgQgjQgQgkgXg3QgYg3gag9Qgag9gZg5QgYg5gRgpQgTgpgGgOQgFgNgFgGQgFgFgJAAQgGAAgFAHQgGAHgHARIjTHoQgMAdgOASQgPARgaAEQgGAAgGABQgHAAgFAAQgFAAgCADQgDACAAADQAAAFAFACQADACAHAAQAhAAAbgBQAbgCAIAAQATAAAZACQAYABAVAAQAGAAAEgCQADgCAAgFQAAgDgCgCQgCgDgIAAIgMAAQgSAAgHgGQgIgFABgLQAAgHADgNQADgNAGgOIArhqQABgDACgCQABgBADAAgAOMBrQgCAAgBgBQgBgCABgCIBOjDQABgCABgCQABgDACAAQABAAABADQABACAAACIBNDEQABABgBACQgBABgDAAgAqDFmQAhABAkgHQAkgGAegUQAsgfATgkQASgkAAgrQAAgkgNggQgNgggegeQgfgeg1gdIghgSQgkgVgTgQQgSgRgHgQQgGgQAAgRQABgbAPgTQAPgTAZgJQAZgKAeAAQAnABAVAMQAVALAJAMQANAQAEAPQAFAPgBAGQAAAOAIAAQAFAAADgGQADgHAAgMQAAgtABgVQABgVAAgHQAAgEgCgCQgDgDgGgBQgQgEgdgEQgegEgogBQg5ABguASQguAUgbAjQgcAjAAAwQgBA0AcAqQAdAqBHApIAvAcQAjAVARATQASASAFASQAFASAAARQgBAqgdAcQgdAcg1ABQgaAAgbgHQgagIgUgRQgVgRgJgcQgEgLgCgLQgCgLAAgIQAAgEgBgEQgCgEgFgBQgFAAgCAGQgDAFAAAJQAAAHgBARQgCAQgBAVQAAAWAAAWQAAAMADAFQADAFAJAEQAbAMAiAEQAjAEAkAAgAJqC5QAAgiAAgcQABgcAAgUQAAgYAJgNQAIgNASgDQAJgBAFgBQAFAAAGAAQAFAAAEgCQACgCABgEQAAgFgFgCQgFgCgIAAQgQAAgTABQgUAAgTABQgUABgOAAQgOAAgWgBQgWgBgaAAQgagBgYAAQgJAAgFACQgFACAAAFQAAAEAEACQAEACAGAAQAKAAAKAAQAKABAGABQAWAFAJAMQAIAMAAAYQABAUABAbQAAAbAAAjIAABWQAAAMgEAIQgEAJgKAFQgRAIgWABQgVACgTgBQhhgBhHgtQhJgsgnhOQgnhOgBhjQABhVAWg2QAXg3AnggQAggaAggMQAhgMAegEQAegDAZAAQA0ABApALQAqAMAcAQQAcARAOAPQASAUAGAUQAGAUABARQABAFADADQABADAFABQAFAAACgFQADgEAAgLQAAg5ABgfQADgfABgOQABgNAAgFQAAgEgCgDQgDgDgHgBQgRgBgUgDQgVgDgPgDQgKgCgagDQgagEgjgCQgigDggAAQgngBgoAEQgoAEgqANQgrANgsAaQgqAZglArQgkAqgVA7QgWA7gBBIQABBfAiBFQAhBEA8AsQA6AsBNAUQBMAVBVAAQAlAAAngEQAogEAmgJQAmgJAegPQAIgEACgGQADgGgBgRgA9OB5QAAA5AAAsQgBAsgCAZQgCARgFAJQgFAJgMADQgGABgHABQgFAAgHAAIgCAAQgIAAgMgCQgPgEgUgIQglgPgggbQghgbgegeQgLgLgZgaQgZgagggiQgggjgggjQgggjgZgaQgYgcgLgOQAMgNAcgcQAcgcAgggQAhghAbgbQAbgbAMgLQAdgdAZgQQAYgQAVgIQAOgEAOgDQAPgDALAAQAGAAAEgCQADgBAAgFQAAgFgEgCQgEgBgHAAQgPAAgUAAQgTABgUAAQgTABgPAAQgNAAgSgBQgTAAgRgBQgRAAgLAAQgHAAgEABQgEACAAAFQAAAEAEACQACACAGABQAHABADAFQAEAFAAAHQgBAMgNARQgNASgUAXQgLAMgaAcQgaAbgfAgQggAhgaAcQgbAcgNAOIgFAAIAAgpQAAhEAAgmQAAglABgTQAAgTABgOQABgYAIgMQAHgNASgDQAJgBAFgBQAFgBAHAAQAGAAADgCQAEgBAAgFQAAgFgFgCQgFgBgJAAQgQAAgWAAQgWABgUAAQgUABgMAAQgLAAgVgBQgVAAgZgBQgaAAgZAAQgKAAgFABQgFACAAAFQAAAFAEABQAEACAIAAQAKAAAKABQAKABAGABQAWAEAIANQAIAMABAXQABAOABATQAAATAAAlQAAAmAABEIAAChQAABAAAA0QgBAygDAeQgDAVgFANQgGAOgNADQgGABgJABQgIABgKAAQgIAAgEACQgDACAAAEQAAAEAFADQAFACAJAAQASAAAXgBQAXAAAUgBQAUgBALAAQAMAAAWABQAVABAaAAQAaABAaAAQAIAAAFgCQAEgDAAgEQAAgEgDgCQgDgCgGAAQgJAAgNgBQgNgBgKgBQgRgDgHgOQgHgNgCgUQgCgeAAgzQgBg0AAhAIAAhSIAFAAIAKAMQAHAJAWAbQAWAaAfAkQAfAkAgAlQAfAkAaAcQAbAdAMALQATASARANQARAMATAHQASAIAYACQAPABAOAAQAOABAVAAIBQAAQADAAADAAQABAAACAAQAQAAAWgBQAVAAATgBQASgBAKAAQARAAAkACQAkABAqAAQAGAAAFgCQAEgCAAgFQAAgCgDgDQgDgDgHAAQgJAAgMAAQgMgBgIgBQgSgDgGgJQgHgJgBgQQgDgZgBgtQAAgsAAg5IAAiJQAAg7AAggQAAgfAAgQQABgQABgMQABgUAGgKQAHgKAQgCQAHgCAFgBQAGAAAGAAQAGAAAEgCQADgCAAgFQAAgEgFgBQgEgCgHAAQgRAAgUABQgUAAgSABQgTAAgLAAQgMAAgTAAQgUgBgVAAQgVgBgPAAQgKAAgFACQgFABAAAEQABAFADACQADACAGAAQAIAAAIABQAHABAHACQANADAGAKQAHAJABATQABAMAAAQQAAAQAAAfQAAAgAAA7gA1rgcQAAgfAAgeQAAgeAAgYQABgYAAgOQAAgHADgDQACgEAFgCQAGgDAPgBQAQgBANAAQAggBAnAFQAmAFAoAQQAoARAmAgQASAQARAbQARAbALAmQAMAlAAAyQAAA9gPAyQgPAygnAhQgkAegrAMQgrAMg3gBQgvAAgZgKQgagKgIgLQgEgHgCgRQgCgQgBgPQgBgNAAgpQgBgqAAg/gA3XB5QAAA2gBAsQAAArgDAZQgCARgFALQgFALgMADQgFABgHABQgHAAgJAAQgIAAgDADQgCADAAACQAAAFAEACQAEACAHAAQANAAAPgBQAOAAAOgBQAPAAAMAAQANgBAHAAQAPAAAVACQAVABAYACQAZACAZABQAZACAWAAQBLgBA2gPQA1gPAkgVQAjgVASgTQAYgXAUggQAUggAMgpQAMgpABgxQgBhFgWgyQgWgxgfgeQgtgsg5gTQg4gTg7gFQg6gEgzABQgZAAgZABQgaAAgWABQgVAAgNAAQgLAAgUAAQgTgBgXAAQgWgBgWAAQgJAAgEACQgFABAAAFQAAAEAEACQAEACAGAAQAJAAAJAAQAJABAFACQATAFAHAJQAIAJABATQAAAMABAQQAAAQAAAfQAAAgAAA7g");
	this.shape_84.setTransform(569.2,132.3972);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("ADfFUQhMgUg7gsQg8gsghhEQgihFgBhfQABhIAWg7QAWg7AjgqQAlgrAqgZQAsgaArgNQApgNApgEQAogEAnABQAhAAAhADQAjACAaAEIAkAFIAkAGQAUADARABQAHABADADQACADAAAEIgBASIgDAtIgCBYQABALgEAEQgCAFgFAAQgFgBgBgDIgEgIQgBgRgGgUQgGgUgSgUQgOgPgcgRQgcgQgpgMQgqgLg0gBQgaAAgdADQgeAEghAMQggAMggAaQgnAggXA3QgWA2AABVQAABjAnBOQAoBOBHAsQBJAtBgABQATABAWgCQAVgBARgIQAKgFAEgJQAEgIAAgMIAAhWIAAg+IgBgvQAAgYgJgMQgJgMgWgFIgPgCIgVAAQgGAAgEgCQgEgCAAgEQAAgFAFgCQAFgCAKAAIAxABIAwABIAkABIAigBIAngBIAjgBQAIAAAFACQAFACAAAFQAAAEgEACQgDACgFAAIgLAAIgNACQgTADgIANQgIANgBAYIAAAwIAAA+IAABmQAAARgDAGQgCAGgIAEQgeAPglAJQgnAJgoAEQgnAEgkAAQhWAAhMgVgAqDFmQgkAAgigEQgjgEgagMQgKgEgDgFQgDgFAAgMIAAgsIADglIACgYQAAgJACgFQADgGAFAAQAEABACAEIACAIQAAAIACALIAFAWQAKAcAUARQAVARAaAIQAaAHAaAAQA1gBAegcQAdgcAAgqQAAgRgFgSQgFgSgSgSQgRgTgjgVIgvgcQhHgpgdgqQgcgqABg0QAAgwAcgjQAbgjAugUQAvgSA4gBQAoABAeAEQAdAEAQAEQAGABADADQADACAAAEIgCAcIgBBCQAAAMgDAHQgDAGgFAAQgHAAgBgOQABgGgEgPQgFgPgNgQQgIgMgWgLQgVgMgngBQgdAAgZAKQgaAJgPATQgPATAAAbQgBARAGAQQAHAQASARQATAQAkAVIAhASQA1AdAfAeQAeAeANAgQAOAggBAkQAAArgSAkQgTAkgsAfQgeAUgkAGQghAGgfAAIgFAAgA0jFhIgygDIgtgDIgkgCIgUABIgaAAIgdABIgbABQgIAAgDgCQgFgCAAgFQAAgCACgDQAEgDAHAAIAQAAIANgCQALgDAGgLQAEgLACgRQADgZABgrIAAhiIAAiJIAAhbIAAgvIgBgcQgBgTgHgJQgIgJgTgFIgOgDIgSAAQgGAAgEgCQgEgCABgEQgBgFAFgBQAEgCAKAAIAsABIApABIAgAAIAhAAIAwgBIAygBQA0gBA5AEQA7AFA4ATQA5ATAtAsQAfAeAWAxQAXAyAABFQgBAxgLApQgNApgUAgQgUAggYAXQgSATgjAVQgjAVg2APQg2APhKABQgXAAgZgCgA0tjKIgeABQgPABgGADQgFACgCAEQgDADABAHIgBAmIAAA2IAAA9IAABhIAABpIABA2IADAfQACARAEAHQAIALAaAKQAZAKAwAAQA3ABAqgMQArgMAkgeQAnghAPgyQAQgygBg9QAAgygLglQgMgmgQgbQgSgbgSgQQgmgggogRQgogQgmgFQgjgFgeAAIgFABgEAolAFeIhSgBIhDgCIg1gBIgogBIgUABIgbAAIgdABIgbABQgHAAgEgCQgEgCAAgFQAAgCACgDQADgDAIAAIAQAAIAMgCQAMgDAFgLQAFgKACgSQADgZAAgrIAAhiIAAiJIAAhaIAAgwIgBgcQgBgTgHgJQgHgJgUgFIgNgDIgSAAQgGAAgFgCQgDgCAAgEQAAgFAFgBQAEgCAJAAIAsABIAqABIAfAAIAgAAIA0ABIA8AAIAzAAIAagBIAUgCIANgDIAHgCIAHgBQAAAAABAAQABAAAAAAQABAAAAABQABAAAAABIABAFIgCAOQgDAKgBAbIgBAPIgCAVIgCAPIgCAIQgCAFgFAAQgEAAgBgCIgCgIIgBgNQAAgIgEgHQgEgLgKgHQgKgIgdgDIgYgCIgnAAIgngBIgZgBQgBAAgBAAQAAAAgBABQAAAAgBAAQAAABgBAAQgBACAAADIAADBIABAGQACADADAAIAbAAIAsAAIArgBIAcgBQAOgCAJgCQAJgDAGgEIAIgIQACgCADAAQADAAACACQABACAAAEQAAADgBALIgFAqIgCATIgBAVIgBAMIgBALQgCAGgFABQgFAAgBgCQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBIAAgNIgCgPQgDgMgLgIQgJgIgWgDIgYgBIgmgBIgngBIgaAAQgBAAgBAAQAAAAgBAAQAAAAAAABQgBAAAAABIgBAGIAAA/IAAAlIAAAsIAAAjQAAAnAZANQAXAOA+gBQARAAAVgCQAVgCARgGQAPgHAIgOQAIgNAEgYQABgGACgDQACgDAEAAQAFAAABAGQACAGAAAGIgDAbQgBARgDARQgCARgDAJQgDAOgJADQgHADgSAAIgGAAgEAhKAFdIgygBIgzgBIglgCQgOgBgFgCQgFgDABgDQgBgDADgCIAHgDQADgCABgHQACgIgDgRIgtlQIgCAAIiuFZQgOAbgGAJQgHAIgGAAQgHAAgIgLIgRgcIgVgoIgdg2Igbg0QgMgXgEgJIgSglIgfhAIggg+IgCAAIgnEtIgCASIgBATQAAALAHAFQAHAFALACIARACIALABQAGAAADADQAEACABADQgBAFgFACQgEACgKAAIgygBIgjgCIglACIgsABIgJgBIgbABIg+gBIhcgBIgSgBQgGgCgBgEQAAgDACgCQACgCAGgBQAFgBADgEQACgFgCgHIg/ieIgDgFIgFgBIi/AAIgEABIgDAFIgrBqQgGAOgDANQgDANAAAHQgBALAIAFQAHAGATAAIALAAQAIAAACADQACACAAADQABAFgEACQgDACgHAAIgtgBIgsgCIgjACIg8ABQgHAAgEgCQgDgCAAgFQgBgDADgCQACgDAFAAIAMAAIAMgBQAagEAPgRQAOgSAMgdIDTnoQAHgRAGgHQAGgHAFAAQAJAAAFAFQAEAGAHANIAXA3IAqBiIA0B2IAxB0IAoBbQAPAjANASQAMARALAGQAKAHAHABIAQACIAPAAIAFABIAFgBIAKAAIAPgBQAPgEAIgSQAHgSACgUIBQn6QACgKAFgFQAFgGAFAAQAFAAAFAFQAGAFAIAPIDZGwIDam1QAEgKAGgFQAFgFAFAAQAFAAAGAHQAFAGADAMIBJHhQAFAkAJASQAIASASAFQARAEALACIASABQAGAAADACQAEACAAADQgBAFgFACQgGADgJAAIgegBgAPZhhIgCAEIhNDDQgBAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAAAAAABQABAAAAAAQAAAAABAAICcAAQABAAABAAQAAAAABAAQAAgBAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIhNjEIgBgEQAAgBAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAQAAAAgBAAQAAAAAAABQgBAAAAAAQAAABgBABgA7jFbIg2gCIgcABIgoABIgmABIgDAAIgGAAIhQAAIgjgBIgdgBQgYgCgSgIQgSgHgRgMQgSgNgSgSQgNgLgbgdQgZgcgggkIg/hJIg1g+IgcgkIgLgMIgFAAIAABSIABB0QABAzABAeQACAUAHANQAHAOARADIAYACIAVABQAHAAACACQADACAAAEQABAEgFADQgFACgIAAIg0gBIgvgBIghgBIggABIgqABIgqABQgJAAgFgCQgEgDAAgEQAAgEACgCQAEgCAIAAIATgBIAOgCQANgDAGgOQAFgNADgVQADgeABgyIABh0IAAihIAAhqIgBg4IgCghQgBgXgIgMQgIgNgWgEIgQgCIgUgBQgIAAgDgCQgFgBAAgFQABgFAFgCQAEgBALAAIAyAAIAuABIAhABIAfgBIAqgBIAmAAQAJAAAGABQAEACAAAFQAAAFgEABQgDACgGAAIgMABIgOACQgSADgHANQgIAMgBAYIgBAhIgBA4IAABqIAAApIAFAAIAogqIA6g9IA6g7IAkgoQAUgXAOgSQANgRAAgMQAAgHgDgFQgDgFgHgBQgHgBgCgCQgEgCAAgEQAAgFAEgCQAEgBAIAAIAbAAIAkABIAfABIAigBIAogBIAiAAQAHAAAFABQADACAAAFQABAFgEABQgDACgHAAQgLAAgOADQgPADgNAEQgWAIgYAQQgZAQgdAdIgnAmIg7A8Ig9A8IgoApIAkAqIA4A9IBABGIA5A8IAkAlQAfAeAgAbQAgAbAlAPQAVAIAOAEIAUACIACAAIANAAIAMgCQAMgDAFgJQAFgJACgRQADgZAAgsIAAhlIAAiJIAAhbIAAgvIgBgcQAAgTgIgJQgGgKgNgDIgOgDIgPgBQgHAAgDgCQgDgCgBgFQAAgEAGgBQAEgCAKAAIAkABIApABIAfAAIAeAAIAmgBIAlgBQAHAAAEACQAFABAAAEQAAAFgDACQgDACgHAAIgMAAIgLADQgRACgHAKQgGAKgBAUIgCAcIAAAvIAABbIAACJIAABlQABAtADAZQACAQAGAJQAGAJASADIAUACIAWAAQAGAAAEADQACADAAACQAAAFgEACQgFACgGAAIhNgBg");
	this.shape_85.setTransform(569.2,132.3972);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#CC3300").ss(37,1,1).p("EAk3ACAQAAA5AAAvQgBAugCAbQgCASgFALQgFAMgNADQgFABgHABQgIAAgJAAQgIAAgDAEQgCACAAADQAAAFAEACQAEACAIAAQANAAAPgBQAPAAAOgBQAPAAANAAQAMgBAIAAQASAAAYABQAXAAAfABQAeABAmABQAlABAvAAQAXABAJgEQAJgDADgPQADgKACgRQADgSACgTQACgSAAgKQAAgHgCgGQgBgGgFgBQgEAAgCAEQgCADgBAGQgEAagJAOQgIAPgPAHQgSAHgVACQgWACgRgBQg/ABgYgOQgZgOAAgqQAAgNAAgXQAAgYAAgXQAAgZAAgPIAAhDQAAgDABgCQABgDACAAQAJAAASAAQATAAAWABQAVABASABQARAAAHABQAWACAKAJQAKAIAEANQABAIAAAIQABAHAAAHQAAADACACQABACAFAAQAFAAACgHQABgGAAgFQAAgEABgKQAAgKABgLQABgNABgIQAEgfABgNQACgMgBgEQAAgDgBgCQgCgDgDAAQgDAAgCADQgEADgEAFQgGAEgJADQgKADgPABQgHABgVAAQgUABgYAAQgYAAgVAAQgUAAgIAAQgDAAgBgCQgBgDAAgEIAAjMQAAgEABgCQACgCACAAQAHAAATABQASAAAXABQAWAAASAAQASABAGABQAdADALAIQAKAIAEAMQADAHABAJQACAJAAAEQAAAGABADQABACAEAAQAFAAACgFQACgFABgDQAAgGABgLQABgLABgLQABgLAAgFQACgcADgLQACgLAAgEQAAgDgBgCQgBgDgEAAQgDAAgDACQgDABgEABQgFABgJACQgJABgMABQgFABgWAAQgWAAgeAAQgeAAgeAAQgfgBgYAAQgXAAgJAAQgMAAgTAAQgUgBgXAAQgYgBgWAAQgJAAgEACQgFACAAAEQAAAFAEACQAEACAGAAQAJAAAJAAQAKABAFACQATAFAIAKQAHAJABAVQABAMAAARQAAARAAAiQAAAiAAA+gARTCfQADAAACABQACACACADIBACoQACAHgDAGQgCAEgFABQgGABgCADQgCACAAADQAAAEAHACQAGABAMAAQA0ABAqAAQAqABAWAAQAUAAAIgBQADABAGAAQAVAAAYgBQAYgCANAAQAMAAAYACQAZABAbAAQAJAAAFgCQAFgCAAgGQAAgDgEgCQgDgDgGAAQgGAAgGgBQgHAAgKgCQgLgCgHgGQgHgFgBgMQAAgKABgJQABgJABgLIAok/IACAAQAPAeASAkQASAlAOAeQAPAfAEAJQADAJANAZQAMAYAPAfQAQAdAOAcQAOAbAHAPQALATAHAMQAIALAIAAQAGAAAHgJQAGgJANgcICzlvIACAAIAuFlQADASgCAIQgBAIgDACQgFABgCACQgDADAAACQAAAEAFADQAFACAPABQANABAYABQAZAAAcABQAcABAXABQAWAAAIAAQAKAAAFgDQAGgCABgFQAAgDgEgDQgDgBgGAAQgIAAgLgCQgLgCgSgEQgSgGgJgTQgIgTgFgmIhLn+QgDgNgFgHQgGgGgFAAQgGAAgFAFQgFAFgGAKIjeHQIjenKQgIgQgGgGQgGgFgFABQgFAAgFAFQgFAGgCAKIhSIZQgCAVgHAUQgIATgQAEQgKABgGAAQgFAAgFAAQgDAAgCABQgCgBgDAAQgHAAgIAAQgHgBgJgBQgIgBgKgHQgLgHgMgSQgOgTgQglQgQgngYg6QgYg6gbhBQgbhAgZg9QgZg8gSgsQgSgrgGgPQgHgOgFgGQgEgGgJAAQgGAAgGAHQgGAIgHASIjYIGQgMAfgPATQgOASgcAEQgGAAgGABQgGAAgGAAQgFAAgCADQgDADAAADQAAAFAEACQAEACAIAAQAhAAAcgBQAbgCAIAAQAUAAAZACQAZABAVAAQAHAAAEgCQADgCAAgFQAAgDgCgDQgCgDgJAAIgLAAQgTAAgIgGQgHgGAAgLQAAgHADgOQADgOAHgPIAshxQABgDACgCQABgBADAAgAOhByQgCAAgBgCQgBgBACgDIBPjPQABgCABgCQACgDABAAQACAAABADQABACAAACIBODQQABACgBABQgBACgDAAgAJ5DFQAAglAAgdQAAgeAAgWQABgZAJgOQAIgNATgDQAIgCAGgBQAFAAAGAAQAFAAAEgCQADgCAAgEQAAgGgFgCQgFgCgJAAQgQAAgUABQgUAAgTABQgUABgPAAQgOAAgXgBQgWgBgaAAQgbgBgZAAQgJAAgFACQgFACAAAGQAAAEAEACQAEACAGAAQAKAAALAAQAKABAGACQAXAEAIAOQAJAMAAAZQABAWAAAdQAAAcAAAlIAABcQABAMgEAJQgFAJgKAGQgRAIgWABQgWACgTgBQhjgBhKgvQhKgwgohSQgohTgBhpQABhaAXg5QAXg7AoghQAhgcAhgNQAhgNAfgEQAegEAbABQA1ABAqAMQAqAMAdARQAdASAOAQQASAVAHAWQAGAVABASQABAFACAEQACADAFAAQAGAAACgEQADgFgBgLQABg9ABghQACghABgOQACgPAAgFQAAgEgCgEQgDgCgIgBQgRgBgVgDQgVgEgQgDQgKgCgbgEQgbgDgigDQgjgDgiAAQgngBgpAEQgqAFgqAOQgsANgtAcQgrAagmAuQglAtgWA+QgWA+gBBNQABBlAjBJQAiBIA8AvQA9AuBOAWQBOAWBXAAQAmAAAogEQApgEAngKQAmgJAfgRQAJgEACgGQACgGAAgTgAqSF8QAiABAlgHQAkgHAfgVQAtghATgmQATgmAAguQAAgmgNgiQgNgigfggQggggg2gfIgigTQglgWgTgRQgTgSgHgRQgGgRAAgSQABgdAPgUQAQgUAagKQAZgKAeAAQAoABAWAMQAWANAIAMQAOARAEAQQAFAQgBAGQAAAPAJAAQAFAAACgHQADgGAAgOQAAgvABgXQACgWAAgHQAAgFgDgCQgDgCgFgCQgRgEgegFQgfgEgpAAQg5AAgvAUQgwAVgcAlQgcAlAAAzQgBA3AdAtQAdAsBJAsIAwAeQAkAWASAUQARATAGATQAFATAAASQgBAtgeAdQgeAeg2ABQgbAAgbgHQgagIgVgSQgVgSgKgfQgEgLgCgLQgCgNAAgIQAAgEgBgFQgCgEgFAAQgFAAgDAFQgCAGAAAKQgBAHgBASQgBARgBAXQgBAWAAAYQAAANADAFQADAGAKAEQAbAMAkAEQAjAFAlAAgA96CAQAAA9AAAvQgBAugCAaQgCASgFAKQgFAKgNADQgFABgHABQgGAAgHAAIgCAAQgIAAgNgCQgPgEgVgIQglgQghgdQghgdgfgfQgMgMgagcQgZgcghgkQghglggglQghglgZgcQgZgegMgPQANgNAdgeQAdgdAggjQAigjAcgcQAbgcAMgMQAegfAZgRQAZgRAWgIQAOgFAPgDQAPgDALAAQAGAAAEgCQAEgCAAgFQAAgFgFgCQgEgBgHAAQgQAAgUAAQgUABgUAAQgUABgPAAQgNAAgTgBQgTAAgRgBQgSAAgLAAQgHAAgEABQgEACAAAFQAAAEAEACQACADAGABQAIABADAFQADAFAAAIQAAANgOASQgNATgUAYQgMANgaAdQgbAeggAiQggAjgcAdQgbAegNAOIgFAAIAAgrQAAhIAAgoQAAgoAAgUQABgUABgPQABgZAIgNQAHgOATgDQAIgBAGgBQAFgBAHAAQAGAAAEgCQAEgCAAgFQAAgFgFgCQgGgBgJAAQgRAAgWAAQgWABgVAAQgUABgMAAQgMAAgWgBQgVAAgagBQgaAAgZAAQgLAAgFABQgFACAAAFQAAAFAEACQAEACAIAAQAKAAALABQAKABAGABQAWAEAJAOQAIANABAYQABAPABAUQAAAUAAAoQAAAoAABIIAACrQAABEAAA3QgBA1gDAgQgDAWgFAOQgGAPgOADQgGABgJABQgIABgLAAQgIAAgDADQgEACAAADQAAAFAFADQAFACAJAAQATAAAYgBQAXAAAUgBQAVgBAMAAQAMAAAWABQAVABAbAAQAbABAaAAQAIAAAGgCQAEgDAAgFQAAgDgDgCQgDgDgGAAQgKAAgNgBQgNgBgKgBQgSgDgHgPQgHgOgCgVQgCgggBg2QAAg3AAhEIAAhXIAFAAIAKANQAHAJAWAdQAYAcAfAmQAfAmAhAnQAgAnAbAdQAbAeANANQATASASAOQARANATAIQATAIAZACQAOABAPAAQAPABAVAAIBSAAQADAAADAAQABAAACAAQARAAAWgBQAVAAAUgBQASgBAKAAQASAAAlACQAlABAqAAQAHAAAFgCQAEgCAAgFQAAgDgDgCQgEgEgGAAQgKAAgMAAQgMgBgJgBQgSgDgGgKQgHgKgBgRQgDgagBgvQAAgvAAg9IAAiRQAAg+AAgiQAAgiAAgRQABgRABgMQABgWAGgKQAHgKARgDQAHgCAFgBQAGAAAGAAQAGAAAEgCQADgCAAgGQAAgDgEgCQgFgCgHAAQgRAAgVABQgVAAgSABQgTAAgLAAQgMAAgUAAQgUgBgWAAQgVgBgQAAQgKAAgFACQgFACAAADQAAAGADACQAEACAGAAQAIAAAIABQAHABAHACQAOAEAGAKQAHAJABAVQABAMAAARQAAARAAAiQAAAiAAA+gA2LgeQAAghAAggQAAggAAgZQAAgaABgOQAAgHACgEQACgEAGgCQAGgDAQgBQAPgCAOAAQAhAAAnAFQAnAFApARQApASAnAiQASARASAcQASAdALAoQAMAoAAA1QAABBgPA1QgQA1goAjQglAfgsANQgrANg4gBQgxAAgagKQgagLgIgMQgFgHgCgSQgCgRAAgQQgBgOgBgsQAAgsAAhDgA36CBQAAA4gBAvQAAAugDAbQgCASgFALQgFAMgMADQgGABgHABQgHAAgKAAQgHAAgDAEQgDACABADQAAAFAEACQADACAIAAQANAAAPgBQAPAAAOgBQAQAAAMAAQANgBAHAAQAQAAAVACQAWABAYACQAZACAaABQAaACAXAAQBMgBA3gQQA3gPAkgWQAlgXASgUQAYgYAUgjQAVgiANgrQAMgsABg0QgBhJgXg0QgXg1gfggQgugug6gVQg6gUg8gEQg7gFg1ABQgZAAgaABQgbAAgWABQgWAAgMAAQgMAAgUAAQgUgBgXAAQgXgBgWAAQgJAAgFACQgFACAAAEQAAAFAEACQAEACAGAAQAJAAAKAAQAJABAFACQATAFAIAKQAIAJABAVQAAAMABARQAAARAAAiQAAAiAAA+g");
	this.shape_86.setTransform(570.975,143.7472);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("ADkFpQhOgWg9guQg8gvgihIQgjhJgBhlQABhNAWg+QAWg+AlgtQAmguArgaQAtgcAsgNQAqgOAqgFQApgEAnABQAiAAAjADIA9AGIAlAGIAlAHQAVADARABQAIABADACQACAEAAAEIgCAUIgDAvIgCBeQABALgDAFQgCAEgGAAQgFAAgCgDIgDgJQgBgSgGgVQgHgWgSgVQgOgQgdgSQgdgRgqgMQgqgMg1gBQgbgBgeAEQgfAEghANQghANghAcQgoAhgXA7QgXA5gBBaQABBpAoBTQAoBSBKAwQBKAvBjABQATABAWgCQAWgBARgIQAKgGAFgJQAEgJgBgMIAAhcIAAhBIgBgzQAAgZgJgMQgIgOgXgEQgGgCgKgBIgVAAQgGAAgEgCQgEgCAAgEQAAgGAFgCQAFgCAJAAIA0ABIAwABIAlABIAjgBIAngBIAkgBQAJAAAFACQAFACAAAGQAAAEgDACQgEACgFAAIgLAAIgOADQgTADgIANQgJAOgBAZIAAA0IAABCIAABrQAAATgCAGQgCAGgJAEQgfARgmAJQgnAKgpAEQgoAEgmAAQhXAAhOgWgAqSF8QglAAgjgFQgkgEgbgMQgKgEgDgGQgDgFAAgNIABguIACgoIACgZQAAgKACgGQADgFAFAAQAFAAACAEIABAJQAAAIACANQACALAEALQAKAfAVASQAVASAaAIQAbAHAbAAQA2gBAegeQAegdABgtQAAgSgFgTQgGgTgRgTQgSgUgkgWIgwgeQhJgsgdgsQgdgtABg3QAAgzAcglQAcglAwgVQAvgUA5AAQApAAAfAEQAeAFARAEQAFACADACQADACAAAFIgCAdIgBBGQAAAOgDAGQgCAHgFAAQgJAAAAgPQABgGgFgQQgEgQgOgRQgIgMgWgNQgWgMgogBQgeAAgZAKQgaAKgQAUQgPAUgBAdQAAASAGARQAHARATASQATARAlAWIAiATQA2AfAgAgQAfAgANAiQANAiAAAmQAAAugTAmQgTAmgtAhQgfAVgkAHQgjAGggAAIgEAAgA1CF2IgzgDIgugDIglgCIgUABIgcAAIgdABIgcABQgIAAgDgCQgEgCAAgFQgBgDADgCQADgEAHAAIARAAIANgCQAMgDAFgMQAFgLACgSQADgbAAguIABhnIAAiSIAAhgIAAgzIgBgdQgBgVgIgJQgIgKgTgFIgOgDIgTAAQgGAAgEgCQgEgCAAgFQAAgEAFgCQAFgCAJAAIAtABIArABIAgAAIAiAAIAxgBIAzgBQA1gBA7AFQA8AEA6AUQA6AVAuAuQAfAgAXA1QAXA0ABBJQgBA0gMAsQgNArgVAiQgUAjgYAYQgSAUglAXQgkAWg3APQg3AQhMABQgXAAgagCgA1NjXIgdACQgQABgGADQgGACgCAEQgCAEAAAHIgBAoIAAA5IAABBIAABnIAABvIACA6IACAhQACASAFAHQAIAMAaALQAaAKAxAAQA4ABArgNQAsgNAlgfQAogjAQg1QAPg1AAhBQAAg1gMgoQgLgogSgdQgSgcgSgRQgngigpgSQgpgRgngFQgkgFgeAAIgGAAgEApiAFzQgvAAglgBIhEgCIg2gBIgqgBIgUABIgcAAIgdABIgcABQgIAAgEgCQgEgCAAgFQAAgDACgCQADgEAIAAIARAAIAMgCQANgDAFgMQAFgLACgSQACgbABguIAAhoIAAiRIAAhgIAAgzIgBgdQgBgVgHgJQgIgKgTgFIgPgDIgSAAQgGAAgEgCQgEgCAAgFQAAgEAFgCQAEgCAJAAIAuABIArABIAfAAIAgAAIA3ABIA8AAIA0AAQAWAAAFgBIAVgCIAOgDIAHgCIAGgCQAEAAABADIABAFIgCAPQgDALgCAcIgBAQIgCAWIgBARIgDAIQgCAFgFAAQgEAAgBgCIgBgJIgCgNQgBgJgDgHQgEgMgKgIQgLgIgdgDIgYgCIgoAAIgpgBIgagBQAAAAgBAAQgBAAAAABQgBAAAAAAQAAABgBAAQgBACAAAEIAADMIABAHQABACADAAIAcAAIAtAAIAsgBIAcgBQAPgBAKgDQAJgDAGgEIAIgIQACgDADAAQADAAACADQABACAAADQABAEgCAMIgFAsIgCAVIgBAVIgBAOIgBALQgCAHgFAAQgFAAgBgCQgCgCAAgDIgBgOIgBgQQgEgNgKgIQgKgJgWgCIgYgBIgngCIgpgBIgbAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAABAAABIgBAFIAABDIAAAoIAAAvIAAAkQAAAqAZAOQAYAOA/gBQARABAWgCQAVgCASgHQAPgHAIgPQAJgOAEgaQABgGACgDQACgEAEAAQAFABABAGQACAGAAAHIgCAcQgCATgDASQgCARgDAKQgDAPgJADQgIADgTAAIgFAAgEAh8AFzIgzgCIg1gBIglgCQgPgBgFgCQgFgDAAgEQAAgCADgDIAHgDQADgCABgIQACgIgDgSIgullIgCAAIizFvQgNAcgGAJQgHAJgGAAQgIAAgIgLIgSgfIgVgqIgeg5Igbg3QgNgZgDgJIgTgoIgghDIghhCIgCAAIgoE/IgCAUIgBATQABAMAHAFQAHAGALACIARACIAMABQAGAAADADQAEACAAADQAAAGgFACQgFACgJAAIg0gBIgkgCIglACIgtABIgJgBIgcABIhAgBIhegBIgSgBQgHgCAAgEQAAgDACgCQACgDAGgBQAFgBACgEQADgGgCgHIhAioIgEgFIgFgBIjDAAIgEABIgDAFIgsBxQgHAPgDAOQgDAOAAAHQAAALAHAGQAIAGATAAIALAAQAJAAACADQACADAAADQAAAFgDACQgEACgHAAIgugBIgtgCIgjACIg9ABQgIAAgEgCQgEgCAAgFQAAgDADgDQACgDAFAAIAMAAIAMgBQAcgEAOgSQAPgTAMgfIDYoGQAHgSAGgIQAGgHAGAAQAJAAAEAGQAFAGAHAOIAYA6IArBoIA0B9IAzB7IAoBhQAQAlAOATQAMASALAHQAKAHAIABIAQACIAPAAIAFABIAFgBIAKAAIAQgBQAQgEAIgTQAHgUACgVIBSoZQACgKAFgGQAFgFAFAAQAFgBAGAFQAGAGAIAQIDeHKIDenQQAGgKAFgFQAFgFAGAAQAFAAAGAGQAFAHADANIBLH+QAFAmAIATQAJATASAGQASAEALACQALACAIAAQAGAAADABQAEADAAADQgBAFgGACQgFADgKAAIgeAAgAPwhnIgCAEIhPDPQgBAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAAAAAQABAAAAAAQABABAAAAICgAAQABAAAAgBQABAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAIhOjQIgBgEQAAgBgBgBQAAAAAAAAQgBgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAABQgBAAAAAAQAAABgBABgA8NFwIg3gCIgcABIgpABIgnABIgDAAIgGAAIhSAAIgkgBIgdgBQgZgCgTgIQgTgIgRgNQgSgOgTgSIgogrQgbgdgggnIhAhNIg3hCIgdgmIgKgNIgFAAIAABXIAAB7QABA2ACAgQACAVAHAOQAHAPASADIAXACIAXABQAGAAADADQADACAAADQAAAFgEADQgGACgIAAIg1gBIgwgBIgigBIghABIgrABIgrABQgJAAgFgCQgFgDAAgFQAAgDAEgCQADgDAIAAIATgBIAPgCQAOgDAGgPQAFgOADgWQADggABg1IAAh7IAAirIAAhwIAAg8IgCgjQgBgYgIgNQgJgOgWgEIgQgCIgVgBQgIAAgEgCQgEgCAAgFQAAgFAFgCQAFgBALAAIAzAAIAvABIAiABIAggBIArgBIAnAAQAJAAAGABQAFACAAAFQAAAFgEACQgEACgGAAIgMABIgOACQgTADgHAOQgIANgBAZIgCAjIAAA8IAABwIAAArIAFAAIAogsIA8hAIA7hAIAmgqQAUgYANgTQAOgSAAgNQAAgIgDgFQgDgFgIgBQgGgBgCgDQgEgCAAgEQAAgFAEgCQAEgBAHAAIAdAAIAkABIAgABIAjgBIAogBIAkAAQAHAAAEABQAFACAAAFQAAAFgEACQgEACgGAAQgLAAgPADQgPADgOAFQgWAIgZARQgZARgeAfIgnAoIg+A/Ig9BAIgqArIAlAtIA6BBIBBBKIA6BAIAmAoQAfAfAhAdQAhAdAlAQQAVAIAPAEIAVACIACAAIANAAIAMgCQANgDAFgKQAFgKACgSQACgaABguIAAhsIAAiRIAAhgIAAgzIgBgdQgBgVgHgJQgGgKgOgEQgHgCgHgBIgQgBQgGAAgEgCQgDgCAAgGQAAgDAFgCQAFgCAKAAIAlABIAqABIAgAAIAeAAIAngBIAmgBQAHAAAFACQAEACAAADQAAAGgDACQgEACgGAAIgMAAIgMADQgRADgHAKQgGAKgBAWIgCAdIAAAzIAABgIAACRIAABsQABAvADAaQABARAHAKQAGAKASADIAVACIAWAAQAGAAAEAEQADACAAADQAAAFgEACQgFACgHAAIhPgBg");
	this.shape_87.setTransform(570.975,143.7472);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66}]}).wait(1));

	// Carpat
	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#BBA957").ss(3,1,1).p("AVlAAQAABwmUBQQmUBPo9AAQo8AAmUhPQmVhQAAhwQAAhvGVhPQGUhQI8AAQI9AAGUBQQGUBPAABvg");
	this.shape_88.setTransform(562.7,540.8);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#7F6D21").s().p("AvQDAQmUhQgBhwQABhvGUhQQGVhPI7AAQI9AAGUBPQGVBQgBBvQABBwmVBQQmUBPo9AAQo7AAmVhPg");
	this.shape_89.setTransform(562.7,540.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#BBA957").ss(3,1,1).p("AewAAQAADHpBCNQpACMsvAAQsuAApBiMQpAiNAAjHQAAjGJAiNQJBiMMuAAQMvAAJACMQJBCNAADGg");
	this.shape_90.setTransform(563.6,544.925);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#7F6D21").s().p("A1vFUQpAiNAAjHQAAjGJAiNQJBiMMuAAQMvAAJACMQJACNAADGQAADHpACNQpACMsvAAQsuAApBiMg");
	this.shape_91.setTransform(563.6,544.925);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#BBA957").ss(3,1,1).p("EAp1AAAQAAFGsQDmQsQDnxVAAQxUAAsQjnQsQjmAAlGQAAlFMQjmQMQjnRUAAQRVAAMQDnQMQDmAAFFg");
	this.shape_92.setTransform(568.625,547.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#7F6D21").s().p("A9kItQsQjnAAlGQAAlGMQjlQMQjnRUAAQRVAAMQDnQMQDlAAFGQAAFGsQDnQsQDmxVAAQxUAAsQjmg");
	this.shape_93.setTransform(568.625,547.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#EDCF6D").s().p("A9kIsQsQjmAAlGQAAlFMQjmQMQjnRUAAQRVAAMQDnQMQDmAAFFQAAFGsQDmQsQDnxVAAQxUAAsQjng");
	this.shape_94.setTransform(568.525,554.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88}]}).wait(1));

	// Floor
	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#B75D0F").s().p("Eh7rACTIAAklMD3XAAAIAAElg");
	this.shape_95.setTransform(606.525,450.1);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_96.setTransform(1318.9516,592.3945,0.9299,0.8426);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_97.setTransform(1160.6516,592.3945,0.9299,0.8426);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_98.setTransform(1002.4016,592.3945,0.9299,0.8426);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_99.setTransform(844.0516,592.3945,0.9299,0.8426);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_100.setTransform(685.7516,592.3945,0.9299,0.8426);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_101.setTransform(527.4016,592.3945,0.9299,0.8426);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_102.setTransform(369.1016,592.3945,0.9299,0.8426);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_103.setTransform(210.8016,592.3945,0.9299,0.8426);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_104.setTransform(52.5016,592.3945,0.9299,0.8426);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_105.setTransform(-105.6984,592.3945,0.9299,0.8426);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_106.setTransform(1318.8016,507.2945,0.9299,0.8426);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_107.setTransform(1160.5016,507.2945,0.9299,0.8426);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_108.setTransform(1002.2516,507.2945,0.9299,0.8426);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_109.setTransform(843.9016,507.2945,0.9299,0.8426);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_110.setTransform(685.6016,507.2945,0.9299,0.8426);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_111.setTransform(527.2516,507.2945,0.9299,0.8426);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_112.setTransform(368.9516,507.2945,0.9299,0.8426);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_113.setTransform(210.6516,507.2945,0.9299,0.8426);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_114.setTransform(52.3516,507.2945,0.9299,0.8426);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#D5721D").s().p("AtSAAIN3n4IMuH4IsuH5g");
	this.shape_115.setTransform(-105.8484,507.2945,0.9299,0.8426);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#E1914C").s().p("Eh7rAOqIAA9TMD3XAAAIAAdTg");
	this.shape_116.setTransform(606.525,558.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95}]}).wait(1));

	// Background_Wall
	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#F2C185").ss(3,1,1).p("EB0ag0MIFOAAMAAABoZIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlNAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAMAAAhoZIJ/AAIFOAAIJ/AAMAAABoZEB0ag0MMAAABoZEAJ/g0MIFOAAIJ/AAIFOAAIJ/AAIFOAAIJ/AAIFOAAIJ/AAIFOAAIJ/AAIFOAAIJ/AAIFOAAMAAABoZEhROg0MIFOAAIJ/AAIFOAAIJ/AAIFOAAIJ/AAIFOAAIJ/AAIFOAAIJ/AAIFNAAIJ/AAMAAABoZEhbNg0MIJ/AAMAAABoZEAPNg0MMAAABoZEAZMg0MMAAABoZEAeag0MMAAABoZEA3mg0MMAAABoZEAtng0MMAAABoZEAoZg0MMAAABoZEA80g0MMAAABoZEBMBg0MMAAABoZEBGzg0MMAAABoZEAAAg0MMAAABoZEgy0g0MMAAABoZEgtmg0MMAAABoZEgjng0MMAAABoZEgeZg0MMAAABoZEgFNg0MMAAABoZEgPMg0MMAAABoZEgUag0MMAAABoZEg8zg0MMAAABoZEhMAg0MMAAABoZEhCBg0MMAAABoZEhbNg0MMAAABoZEBlNg0MMAAABoZEBbOg0MMAAABoZEBWAg0MMAAABoZEBqbg0MIJ/AAEhqag0MMAAABoZEhvog0MMAAABoZEhgbg0MIFOAA");
	this.shape_117.setTransform(602.65,320.575);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#F2D7B6").s().p("EB0aA0MMAAAhoXIFOAAMAAABoXgEBqbA0MMAAAhoXIJ/AAMAAABoXgEBlNA0MIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlNAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAIp/AAIlOAAMAAAhoXMAAABoXIp/AAMAAAhoXIJ/AAIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFNAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXMAAAhoXIJ/AAMAAABoXMAAAhoXIFOAAMAAABoXgEhvoA0MMAAAhoXIFOAAMAAABoXgEh5nA0MMAAAhoXIJ/AAMAAABoXg");
	this.shape_118.setTransform(602.65,320.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_118},{t:this.shape_117}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(263.2,305.1,1134.8999999999999,351.1);
// library properties:
lib.properties = {
	id: 'E95DD16BE51606408462A5D7C878A2D7',
	width: 1136,
	height: 640,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['E95DD16BE51606408462A5D7C878A2D7'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;